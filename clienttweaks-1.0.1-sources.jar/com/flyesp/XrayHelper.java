package com.flyesp;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

public class XrayHelper {
    private static final Set<class_2248> VISIBLE_BLOCKS = new HashSet<>();

    static {
        VISIBLE_BLOCKS.add(class_2246.field_10418); VISIBLE_BLOCKS.add(class_2246.field_29219);
        VISIBLE_BLOCKS.add(class_2246.field_10212); VISIBLE_BLOCKS.add(class_2246.field_29027);
        VISIBLE_BLOCKS.add(class_2246.field_10571); VISIBLE_BLOCKS.add(class_2246.field_29026);
        VISIBLE_BLOCKS.add(class_2246.field_10442); VISIBLE_BLOCKS.add(class_2246.field_29029);
        VISIBLE_BLOCKS.add(class_2246.field_10013); VISIBLE_BLOCKS.add(class_2246.field_29220);
        VISIBLE_BLOCKS.add(class_2246.field_10090); VISIBLE_BLOCKS.add(class_2246.field_29028);
        VISIBLE_BLOCKS.add(class_2246.field_10080); VISIBLE_BLOCKS.add(class_2246.field_29030);
        VISIBLE_BLOCKS.add(class_2246.field_27120); VISIBLE_BLOCKS.add(class_2246.field_29221);
        VISIBLE_BLOCKS.add(class_2246.field_23077); VISIBLE_BLOCKS.add(class_2246.field_10213);
        VISIBLE_BLOCKS.add(class_2246.field_22109);
        VISIBLE_BLOCKS.add(class_2246.field_10034); VISIBLE_BLOCKS.add(class_2246.field_10380);
        VISIBLE_BLOCKS.add(class_2246.field_10443); VISIBLE_BLOCKS.add(class_2246.field_16328);
        VISIBLE_BLOCKS.add(class_2246.field_10603);
        VISIBLE_BLOCKS.add(class_2246.field_10199); VISIBLE_BLOCKS.add(class_2246.field_10407);
        VISIBLE_BLOCKS.add(class_2246.field_10063); VISIBLE_BLOCKS.add(class_2246.field_10203);
        VISIBLE_BLOCKS.add(class_2246.field_10600); VISIBLE_BLOCKS.add(class_2246.field_10275);
        VISIBLE_BLOCKS.add(class_2246.field_10051); VISIBLE_BLOCKS.add(class_2246.field_10140);
        VISIBLE_BLOCKS.add(class_2246.field_10320); VISIBLE_BLOCKS.add(class_2246.field_10532);
        VISIBLE_BLOCKS.add(class_2246.field_10268); VISIBLE_BLOCKS.add(class_2246.field_10605);
        VISIBLE_BLOCKS.add(class_2246.field_10373); VISIBLE_BLOCKS.add(class_2246.field_10055);
        VISIBLE_BLOCKS.add(class_2246.field_10068); VISIBLE_BLOCKS.add(class_2246.field_10371);
        VISIBLE_BLOCKS.add(class_2246.field_10201); VISIBLE_BLOCKS.add(class_2246.field_10234);
        VISIBLE_BLOCKS.add(class_2246.field_10205); VISIBLE_BLOCKS.add(class_2246.field_10085);
        VISIBLE_BLOCKS.add(class_2246.field_22108);
        VISIBLE_BLOCKS.add(class_2246.field_10164); VISIBLE_BLOCKS.add(class_2246.field_10382);
        VISIBLE_BLOCKS.add(class_2246.field_10260); VISIBLE_BLOCKS.add(class_2246.field_47336);
    }

    public static boolean isVisibleBlock(class_2248 block) { return VISIBLE_BLOCKS.contains(block); }

    public static boolean isStashBlock(class_2248 block) {
        return block == class_2246.field_10034 || block == class_2246.field_10380 || block == class_2246.field_10443
                || block == class_2246.field_16328 || block.method_63499().contains("shulker_box");
    }
}
