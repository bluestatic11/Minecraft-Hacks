package com.flyesp;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_310;

/**
 * Smart Fake Lag v2 — designed for anti-cheat servers like MinemenClub.
 *
 * Instead of holding ALL packets (instant flag), it only delays MOVEMENT packets.
 * Keep-alive, chat, and other critical packets pass through normally.
 * Releases packets gradually (one per tick) instead of dumping all at once.
 *
 * This makes you rubber-band/teleport without triggering packet burst detection.
 */
public class FakeLag {
    private static final Queue<DelayedPacket> packetQueue = new ConcurrentLinkedQueue<>();
    private static long delayMs = 400; // 400ms default — looks like bad wifi
    public static volatile boolean sendDirect = false;

    public static void setDelay(long ms) { delayMs = ms; }
    public static long getDelay() { return delayMs; }

    /**
     * Check if a packet should be delayed.
     * Only delay movement packets — let everything else through.
     */
    public static boolean shouldDelay(class_2596<?> packet) {
        // Only delay movement packets
        return packet instanceof class_2828
                || packet instanceof class_2828.class_2829
                || packet instanceof class_2828.class_2830
                || packet instanceof class_2828.class_2831
                || packet instanceof class_2828.class_5911;
    }

    public static void queuePacket(class_2596<?> packet) {
        // Add random jitter to delay (±50ms) so it looks like real lag
        long jitter = ThreadLocalRandom.current().nextLong(-50, 50);
        long sendAt = System.currentTimeMillis() + delayMs + jitter;
        packetQueue.add(new DelayedPacket(packet, sendAt));
    }

    /**
     * Called every tick — releases packets gradually (max 2 per tick)
     * instead of dumping all at once.
     */
    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.method_1562() == null) return;

        long now = System.currentTimeMillis();
        int sent = 0;

        while (!packetQueue.isEmpty() && packetQueue.peek().sendTime <= now && sent < 2) {
            DelayedPacket dp = packetQueue.poll();
            if (dp != null) {
                sendDirect = true;
                mc.method_1562().method_52787(dp.packet);
                sendDirect = false;
                sent++;
            }
        }
    }

    /**
     * Flush all queued packets gradually over a few ticks (called when disabling).
     */
    public static void flush() {
        class_310 mc = class_310.method_1551();
        if (mc.method_1562() == null) return;

        // Send max 3 per call to avoid burst detection
        int sent = 0;
        while (!packetQueue.isEmpty() && sent < 3) {
            DelayedPacket dp = packetQueue.poll();
            if (dp != null) {
                sendDirect = true;
                mc.method_1562().method_52787(dp.packet);
                sendDirect = false;
                sent++;
            }
        }
    }

    public static boolean hasQueued() {
        return !packetQueue.isEmpty();
    }

    public static int getQueueSize() {
        return packetQueue.size();
    }

    private static class DelayedPacket {
        final class_2596<?> packet;
        final long sendTime;

        DelayedPacket(class_2596<?> packet, long sendTime) {
            this.packet = packet;
            this.sendTime = sendTime;
        }
    }
}
