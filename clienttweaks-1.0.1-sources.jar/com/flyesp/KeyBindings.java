package com.flyesp;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {
    public static class_304 FLY_TOGGLE;
    public static class_304 ESP_TOGGLE;
    public static class_304 XRAY_TOGGLE;
    public static class_304 ORE_FINDER_TOGGLE;
    public static class_304 SEED_CRACKER_TOGGLE;
    public static class_304 AUTO_TOTEM_TOGGLE;
    public static class_304 AUTO_CLICKER_TOGGLE;
    public static class_304 TRIGGER_BOT_TOGGLE;
    public static class_304 AUTO_SPRINT_TOGGLE;
    public static class_304 NO_FALL_TOGGLE;
    public static class_304 FAKE_LAG_TOGGLE;
    public static class_304 AIM_ASSIST_TOGGLE;
    public static class_304 BASE_FINDER_TOGGLE;
    public static class_304 ANTI_KB_TOGGLE;
    public static class_304 AUTO_XP_TOGGLE;
    public static class_304 AUTO_MINE_TOGGLE;
    public static class_304 REACH_TOGGLE;
    public static class_304 VELOCITY_TOGGLE;
    public static class_304 AUTO_GAP_TOGGLE;
    public static class_304 RADAR_TOGGLE;
    public static class_304 AUTO_TOOL_TOGGLE;
    public static class_304 GAMEMODE_SWITCH;
    public static class_304 SAFE_ANCHOR_TOGGLE;
    public static class_304 AUTO_CRYSTAL_TOGGLE;
    public static class_304 HUD_TOGGLE;
    public static class_304 PANIC;
    public static class_304 VANISH_DETECT_TOGGLE;

    public static void register() {
        FLY_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Render Mode", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_BRACKET, class_304.class_11900.field_62556));
        ESP_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Entity Outlines", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F9, class_304.class_11900.field_62556));
        XRAY_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Block Filter", class_3675.class_307.field_1668, GLFW.GLFW_KEY_X, class_304.class_11900.field_62556));
        ORE_FINDER_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Chunk Analyzer", class_3675.class_307.field_1668, GLFW.GLFW_KEY_Z, class_304.class_11900.field_62556));
        SEED_CRACKER_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "World Inspector", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F6, class_304.class_11900.field_62556));
        AUTO_TOTEM_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Offhand Assist", class_3675.class_307.field_1668, GLFW.GLFW_KEY_V, class_304.class_11900.field_62556));
        AUTO_CLICKER_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Input Repeat", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F4, class_304.class_11900.field_62556));
        TRIGGER_BOT_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Auto Interact", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F1, class_304.class_11900.field_62556));
        AUTO_SPRINT_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Toggle Sprint", class_3675.class_307.field_1668, GLFW.GLFW_KEY_H, class_304.class_11900.field_62556));
        NO_FALL_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Fall Override", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F3, class_304.class_11900.field_62556));
        FAKE_LAG_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Packet Buffer", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F5, class_304.class_11900.field_62556));
        AIM_ASSIST_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Camera Smooth", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F8, class_304.class_11900.field_62556));
        BASE_FINDER_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Block Scanner", class_3675.class_307.field_1668, GLFW.GLFW_KEY_B, class_304.class_11900.field_62556));
        ANTI_KB_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Motion Fix", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F7, class_304.class_11900.field_62556));
        AUTO_XP_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Repair Assist", class_3675.class_307.field_1668, GLFW.GLFW_KEY_N, class_304.class_11900.field_62556));
        AUTO_MINE_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Break Assist", class_3675.class_307.field_1668, GLFW.GLFW_KEY_M, class_304.class_11900.field_62556));
        REACH_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Range Tweak", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F10, class_304.class_11900.field_62556));
        VELOCITY_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Motion Reduce", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F11, class_304.class_11900.field_62556));
        AUTO_GAP_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Auto Use", class_3675.class_307.field_1668, GLFW.GLFW_KEY_C, class_304.class_11900.field_62556));
        RADAR_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Area Scanner", class_3675.class_307.field_1668, GLFW.GLFW_KEY_R, class_304.class_11900.field_62556));
        AUTO_TOOL_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Tool Select", class_3675.class_307.field_1668, GLFW.GLFW_KEY_J, class_304.class_11900.field_62556));
        GAMEMODE_SWITCH = KeyBindingHelper.registerKeyBinding(new class_304(
                "Mode Switch", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F12, class_304.class_11900.field_62556));
        SAFE_ANCHOR_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Place Assist", class_3675.class_307.field_1668, GLFW.GLFW_KEY_Y, class_304.class_11900.field_62556));
        AUTO_CRYSTAL_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Item Placer", class_3675.class_307.field_1668, GLFW.GLFW_KEY_U, class_304.class_11900.field_62556));
        HUD_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Overlay Toggle", class_3675.class_307.field_1668, GLFW.GLFW_KEY_BACKSLASH, class_304.class_11900.field_62556));
        PANIC = KeyBindingHelper.registerKeyBinding(new class_304(
                "Performance Reset", class_3675.class_307.field_1668, GLFW.GLFW_KEY_END, class_304.class_11900.field_62556));
        VANISH_DETECT_TOGGLE = KeyBindingHelper.registerKeyBinding(new class_304(
                "Player Tracker", class_3675.class_307.field_1668, GLFW.GLFW_KEY_K, class_304.class_11900.field_62556));
    }
}
