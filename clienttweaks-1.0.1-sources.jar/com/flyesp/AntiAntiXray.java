package com.flyesp;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;

public class AntiAntiXray {
    private static final Set<class_2338> confirmedOres = ConcurrentHashMap.newKeySet();
    private static final Map<class_2248, int[]> ORE_Y_RANGES = new HashMap<>();

    static {
        ORE_Y_RANGES.put(class_2246.field_10442, new int[]{-64, 16}); ORE_Y_RANGES.put(class_2246.field_29029, new int[]{-64, 16});
        ORE_Y_RANGES.put(class_2246.field_10571, new int[]{-64, 32}); ORE_Y_RANGES.put(class_2246.field_29026, new int[]{-64, 32});
        ORE_Y_RANGES.put(class_2246.field_10013, new int[]{-16, 320}); ORE_Y_RANGES.put(class_2246.field_29220, new int[]{-16, 320});
        ORE_Y_RANGES.put(class_2246.field_10090, new int[]{-64, 64}); ORE_Y_RANGES.put(class_2246.field_29028, new int[]{-64, 64});
        ORE_Y_RANGES.put(class_2246.field_10080, new int[]{-64, 15}); ORE_Y_RANGES.put(class_2246.field_29030, new int[]{-64, 15});
        ORE_Y_RANGES.put(class_2246.field_27120, new int[]{-16, 112}); ORE_Y_RANGES.put(class_2246.field_29221, new int[]{-16, 112});
        ORE_Y_RANGES.put(class_2246.field_10418, new int[]{0, 320}); ORE_Y_RANGES.put(class_2246.field_29219, new int[]{0, 320});
        ORE_Y_RANGES.put(class_2246.field_10212, new int[]{-64, 320}); ORE_Y_RANGES.put(class_2246.field_29027, new int[]{-64, 320});
        ORE_Y_RANGES.put(class_2246.field_23077, new int[]{0, 128}); ORE_Y_RANGES.put(class_2246.field_10213, new int[]{0, 128});
        ORE_Y_RANGES.put(class_2246.field_22109, new int[]{8, 119});
    }

    public static boolean isOre(class_2248 b) { return ORE_Y_RANGES.containsKey(b); }
    public static void confirmOre(class_2338 pos) { confirmedOres.add(pos.method_10062()); }
    public static void removeConfirmed(class_2338 pos) { confirmedOres.remove(pos); }
    public static void clearConfirmed() { confirmedOres.clear(); }

    public static float getConfidence(class_1937 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        class_2248 block = state.method_26204();
        if (!isOre(block)) return 0.0f;
        if (confirmedOres.contains(pos)) return 1.0f;

        float score = 0.0f;
        int y = pos.method_10264();
        int[] range = ORE_Y_RANGES.get(block);
        if (range != null) {
            if (y < range[0] || y > range[1]) return 0.0f;
            score += 0.1f;
        }

        // EXPOSED FACE — this is the #1 indicator on Mode 2 servers.
        // If an ore block has air, lava, water, or any transparent block next to it,
        // the server HAD to send the real block data. This means it's confirmed real.
        boolean exposed = false;
        int exposedFaces = 0;
        for (class_2350 dir : class_2350.values()) {
            class_2680 ns = level.method_8320(pos.method_10093(dir));
            if (ns.method_26215() || !ns.method_26225() || ns.method_27852(class_2246.field_10164) || ns.method_27852(class_2246.field_10382)
                    || ns.method_27852(class_2246.field_10543)) {
                exposed = true;
                exposedFaces++;
            }
        }
        if (exposed) score += 0.6f;
        if (exposedFaces >= 2) score += 0.1f; // Multiple exposed faces = very likely real

        // VEIN CHECK — real ores form veins, Mode 2 noise is random
        int same = 0, diff = 0, nonOre = 0;
        for (class_2350 dir : class_2350.values()) {
            class_2248 nb = level.method_8320(pos.method_10093(dir)).method_26204();
            if (nb == block) same++;
            else if (isOre(nb)) diff++;
            else nonOre++;
        }
        if (same >= 2) score += 0.2f; // Strong vein = likely real
        else if (same >= 1) score += 0.1f;

        // MODE 2 KILLER: if ALL 6 neighbors are different ores = definitely noise
        if (same == 0 && diff >= 4) score *= 0.05f; // Almost certainly fake
        if (same == 0 && diff >= 3) score *= 0.1f;

        // If the ore has NO non-ore neighbors, it's surrounded by other ores = Mode 2 noise
        if (nonOre == 0 && same == 0) score *= 0.05f;

        // Context check
        String name = block.method_63499();
        if (name.contains("deepslate") && y > 8) score *= 0.3f;
        else if (!name.contains("deepslate") && !name.contains("nether") && y < -8) score *= 0.3f;

        // Ancient debris extra check — only spawns in veins of 1-3 at Y 8-22 commonly
        if (block == class_2246.field_22109) {
            if (y < 8 || y > 22) score *= 0.5f; // Less common outside peak range
            // Debris surrounded by only other ores = fake
            if (nonOre == 0) score *= 0.1f;
        }

        return Math.min(score, 1.0f);
    }

    /**
     * Optimized ore scan using chunk sections instead of brute-force block iteration.
     * Skips empty sections entirely, which is a massive speedup underground.
     */
    public static List<OreResult> scanNearbyOres(class_1937 level, class_2338 center, int chunkRange, float minConf) {
        List<OreResult> results = new ArrayList<>();
        int pcx = center.method_10263() >> 4;
        int pcz = center.method_10260() >> 4;

        for (int cx = pcx - chunkRange; cx <= pcx + chunkRange; cx++) {
            for (int cz = pcz - chunkRange; cz <= pcz + chunkRange; cz++) {
                if (!level.method_8393(cx, cz)) continue;
                class_2818 chunk = (class_2818) level.method_8497(cx, cz);
                class_2826[] sections = chunk.method_12006();

                for (int si = 0; si < sections.length; si++) {
                    class_2826 section = sections[si];
                    if (section == null || section.method_38292()) continue;

                    int baseY = level.method_31607() + (si * 16);
                    for (int x = 0; x < 16; x++)
                        for (int y = 0; y < 16; y++)
                            for (int z = 0; z < 16; z++) {
                                class_2680 state = section.method_12254(x, y, z);
                                if (!isOre(state.method_26204())) continue;
                                class_2338 pos = new class_2338(cx * 16 + x, baseY + y, cz * 16 + z);
                                float c = getConfidence(level, pos);
                                if (c >= minConf) results.add(new OreResult(pos, state.method_26204(), c));
                            }
                }
            }
        }
        return results;
    }

    public static class OreResult {
        public final class_2338 pos; public final class_2248 block; public final float confidence;
        public OreResult(class_2338 pos, class_2248 block, float confidence) { this.pos = pos; this.block = block; this.confidence = confidence; }
    }
}
