package com.flyesp;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;

/**
 * Auto Crystal — places end crystals on obsidian/bedrock and instantly breaks them.
 *
 * Conditions:
 * - Looking at obsidian or bedrock
 * - Block is at or below player's Y level
 * - An enemy player is nearby at same level or higher
 * - Space above the block is clear for crystal placement
 *
 * Flow each tick:
 * 1. Break any existing crystals near the target block (attack them)
 * 2. Place a new crystal on the block
 * 3. Immediately break it next tick
 *
 * Swaps to end crystal, places, swaps back — all automated.
 */
public class AutoCrystal {
    private static int cooldown = 0;
    private static int previousSlot = -1;
    private static boolean swapped = false;
    private static final double PLACE_RANGE = 4.5;
    private static final double ENEMY_RANGE = 10.0;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1687 == null || mc.field_1755 != null) return;

        if (cooldown > 0) { cooldown--; return; }

        class_746 player = mc.field_1724;

        // Step 1: Always try to break nearby crystals first (highest priority)
        if (breakNearbyCrystal(mc, player)) {
            cooldown = ThreadLocalRandom.current().nextInt(1, 3);
            return;
        }

        // Swap back if we placed last tick
        if (swapped && previousSlot >= 0) {
            player.method_31548().method_61496(previousSlot);
            swapped = false;
            previousSlot = -1;
        }

        // Step 2: Check if looking at obsidian/bedrock
        if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1332) return;
        class_3965 blockHit = (class_3965) mc.field_1765;
        class_2338 targetBlock = blockHit.method_17777();
        class_2680 state = mc.field_1687.method_8320(targetBlock);

        if (!state.method_27852(class_2246.field_10540) && !state.method_27852(class_2246.field_9987)) return;

        // Step 3: Block must be at or below player Y level
        if (targetBlock.method_10264() > player.method_24515().method_10264()) return;

        // Step 4: Check for enemy player nearby at same level or higher
        if (!isEnemyNearbyAndHigher(mc, player, targetBlock)) return;

        // Step 5: Check space above block is clear for crystal
        class_2338 crystalPos = targetBlock.method_10084();
        if (!mc.field_1687.method_8320(crystalPos).method_26215()) return;
        if (!mc.field_1687.method_8320(crystalPos.method_10084()).method_26215()) return;

        // Check no existing crystal there
        List<class_1511> existing = mc.field_1687.method_18467(class_1511.class,
                new class_238(crystalPos).method_1014(0.5));
        if (!existing.isEmpty()) return;

        // Step 6: Check distance
        double dist = player.method_5836(1.0f).method_1022(
                new class_243(targetBlock.method_10263() + 0.5, targetBlock.method_10264() + 1.0, targetBlock.method_10260() + 0.5));
        if (dist > PLACE_RANGE) return;

        // Step 7: Find end crystal in hotbar
        int crystalSlot = findCrystalSlot(player.method_31548());
        if (crystalSlot == -1) return;

        // Step 8: Swap to crystal and place
        previousSlot = player.method_31548().method_67532();
        player.method_31548().method_61496(crystalSlot);
        swapped = true;

        // Place crystal on top of the block
        class_3965 placeHit = new class_3965(
                new class_243(targetBlock.method_10263() + 0.5, targetBlock.method_10264() + 1.0, targetBlock.method_10260() + 0.5),
                class_2350.field_11036,
                targetBlock,
                false
        );
        mc.field_1761.method_2896(player, class_1268.field_5808, placeHit);

        cooldown = ThreadLocalRandom.current().nextInt(2, 5); // 2-4 tick delay between places
    }

    /**
     * Find and attack the nearest end crystal within range.
     * Returns true if a crystal was attacked.
     */
    private static boolean breakNearbyCrystal(class_310 mc, class_746 player) {
        double closestDist = PLACE_RANGE + 1;
        class_1511 closest = null;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1511 crystal)) continue;
            double dist = player.method_5739(crystal);
            if (dist < closestDist && dist <= PLACE_RANGE) {
                // Only break crystals that would damage enemies, not us
                // Check if any enemy is closer to the crystal than us
                boolean enemyCloser = false;
                for (class_1297 other : mc.field_1687.method_18112()) {
                    if (other == player || !(other instanceof class_1657)) continue;
                    if (other.method_5739(crystal) <= dist + 2) {
                        enemyCloser = true;
                        break;
                    }
                }
                if (enemyCloser || crystal.method_24515().method_10264() <= player.method_24515().method_10264()) {
                    closest = crystal;
                    closestDist = dist;
                }
            }
        }

        if (closest != null) {
            mc.field_1761.method_2918(player, closest);
            player.method_6104(class_1268.field_5808);
            cooldown = ThreadLocalRandom.current().nextInt(1, 4); // Random delay after break
            return true;
        }
        return false;
    }

    /**
     * Check if an enemy player is nearby and at the same Y level or higher than the target block.
     */
    private static boolean isEnemyNearbyAndHigher(class_310 mc, class_746 player, class_2338 targetBlock) {
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity == player) continue;
            if (!(entity instanceof class_1657)) continue;
            if (!entity.method_5805()) continue;

            double dist = player.method_5739(entity);
            if (dist > ENEMY_RANGE) continue;

            // Enemy must be at same level or higher than the crystal placement
            if (entity.method_24515().method_10264() >= targetBlock.method_10264()) {
                return true;
            }
        }
        return false;
    }

    private static int findCrystalSlot(class_1661 inv) {
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_31574(class_1802.field_8301)) return i;
        }
        return -1;
    }
}
