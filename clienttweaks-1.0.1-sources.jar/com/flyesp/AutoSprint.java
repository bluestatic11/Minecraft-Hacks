package com.flyesp;

import net.minecraft.class_310;
import net.minecraft.class_746;

public class AutoSprint {
    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1755 != null) return;
        class_746 player = mc.field_1724;
        if (player.field_3913.field_54155.comp_3159() && !player.method_5624()
                && !player.method_6115() && !player.method_5765()
                && player.method_7344().method_7586() > 6) {
            player.method_5728(true);
        }
    }
}
