package com.flyesp.mixin;

import com.flyesp.FlyEspModClient;
import com.flyesp.XrayHelper;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_4970.class_4971.class, priority = 1500)
public abstract class BlockStateMixin {
    @Inject(method = "isSolidRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void onIsSolidRender(CallbackInfoReturnable<Boolean> cir) {
        if (!FlyEspModClient.xrayEnabled) return;
        class_2680 state = (class_2680)(Object)this;
        if (!XrayHelper.isVisibleBlock(state.method_26204())) cir.setReturnValue(false);
    }

    @Inject(method = "skipRendering", at = @At("HEAD"), cancellable = true, require = 0)
    private void onSkipRendering(class_2680 adjacent, class_2350 dir, CallbackInfoReturnable<Boolean> cir) {
        if (!FlyEspModClient.xrayEnabled) return;
        class_2680 self = (class_2680)(Object)this;
        if (!XrayHelper.isVisibleBlock(self.method_26204())) cir.setReturnValue(true);
    }
}
