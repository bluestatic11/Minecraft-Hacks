package com.flyesp.mixin;

import com.flyesp.FlyEspModClient;
import com.flyesp.ReachExtender;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_1657.class, priority = 1500)
public abstract class ReachMixin {
    @Inject(method = "entityInteractionRange", at = @At("HEAD"), cancellable = true, require = 0)
    private void onEntityInteractionRange(CallbackInfoReturnable<Double> cir) {
        if (FlyEspModClient.reachEnabled) {
            cir.setReturnValue(ReachExtender.getReach());
        }
    }
}
