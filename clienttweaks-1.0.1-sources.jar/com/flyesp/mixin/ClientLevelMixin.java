package com.flyesp.mixin;

import com.flyesp.AntiAntiXray;
import com.flyesp.FlyEspModClient;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_638.class, priority = 1500)
public abstract class ClientLevelMixin {
    @Inject(method = "setServerVerifiedBlockState", at = @At("TAIL"), require = 0)
    private void onBlockUpdate(class_2338 pos, class_2680 state, int flags, CallbackInfo ci) {
        if (!FlyEspModClient.oreFinderEnabled) return;
        if (AntiAntiXray.isOre(state.method_26204())) AntiAntiXray.confirmOre(pos);
        else AntiAntiXray.removeConfirmed(pos);
    }
}
