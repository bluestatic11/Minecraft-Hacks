package com.flyesp.mixin;

import com.flyesp.FlyEspModClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_310;

@Mixin(value = class_1309.class, priority = 1500)
public abstract class PlayerKnockbackMixin {

    @Inject(method = "knockback", at = @At("HEAD"), cancellable = true, require = 0)
    private void onKnockback(double strength, double x, double z, CallbackInfo ci) {
        class_1309 self = (class_1309)(Object)this;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || self != mc.field_1724) return;
        if (FlyEspModClient.antiKBEnabled) { ci.cancel(); return; }
        if (FlyEspModClient.velocityEnabled) {
            ci.cancel();
            double remaining = 1.0 - (0.80 + ThreadLocalRandom.current().nextDouble() * 0.10);
            self.method_18799(self.method_18798().method_1031(
                    -Math.sin(Math.atan2(z, x)) * strength * remaining, 0.0,
                    Math.cos(Math.atan2(z, x)) * strength * remaining));
        }
    }

    @Inject(method = "handleDamageEvent", at = @At("HEAD"), cancellable = true, require = 0)
    private void onDamageEvent(class_1282 source, CallbackInfo ci) {
        class_1309 self = (class_1309)(Object)this;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && self == mc.field_1724 && FlyEspModClient.antiKBEnabled) ci.cancel();
    }

    @Inject(method = "animateHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void onAnimateHurt(float yaw, CallbackInfo ci) {
        class_1309 self = (class_1309)(Object)this;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && self == mc.field_1724 && FlyEspModClient.antiKBEnabled) ci.cancel();
    }
}
