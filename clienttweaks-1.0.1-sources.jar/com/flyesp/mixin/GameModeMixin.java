package com.flyesp.mixin;

import com.flyesp.FlyEspModClient;
import net.minecraft.class_1934;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_636.class, priority = 1500)
public abstract class GameModeMixin {
    @Shadow private class_1934 localPlayerMode;

    @Inject(method = "getPlayerMode", at = @At("HEAD"), cancellable = true, require = 0)
    private void onGetPlayerMode(CallbackInfoReturnable<class_1934> cir) {
        if (FlyEspModClient.flyEnabled && localPlayerMode == class_1934.field_9215)
            cir.setReturnValue(class_1934.field_9215);
    }
}
