package com.flyesp.mixin;

import com.flyesp.FlyEspModClient;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_1297.class, priority = 1500)
public abstract class ExplosionKBMixin {
    @Inject(method = "push(DDD)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void onPush(double x, double y, double z, CallbackInfo ci) {
        if (!FlyEspModClient.antiKBEnabled) return;
        class_1297 self = (class_1297)(Object)this;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && self == mc.field_1724) ci.cancel();
    }
}
