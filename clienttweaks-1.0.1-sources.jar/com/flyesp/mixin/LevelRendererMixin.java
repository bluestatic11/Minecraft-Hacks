package com.flyesp.mixin;

import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class LevelRendererMixin {
    @Inject(method = "allChanged", at = @At("HEAD"))
    private void onAllChanged(CallbackInfo ci) {}
}
