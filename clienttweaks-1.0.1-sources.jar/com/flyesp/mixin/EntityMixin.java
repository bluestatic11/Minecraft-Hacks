package com.flyesp.mixin;

import com.flyesp.FlyEspModClient;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_1297.class, priority = 1500)
public abstract class EntityMixin {
    @Inject(method = "isCurrentlyGlowing", at = @At("HEAD"), cancellable = true, require = 0)
    private void onIsGlowing(CallbackInfoReturnable<Boolean> cir) {
        if (!FlyEspModClient.espEnabled) return;
        class_1297 self = (class_1297)(Object)this;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || self == mc.field_1724) return;
        if (self instanceof class_1657 || self instanceof class_1308 || self instanceof class_1542)
            cir.setReturnValue(true);
    }

    @Inject(method = "getTeamColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void onGetTeamColor(CallbackInfoReturnable<Integer> cir) {
        if (!FlyEspModClient.espEnabled) return;
        class_1297 self = (class_1297)(Object)this;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || self == mc.field_1724) return;
        if (self instanceof class_1657) cir.setReturnValue(0xFF0000);
        else if (self instanceof class_1588) cir.setReturnValue(0xAA00FF);
        else if (self instanceof class_1308) cir.setReturnValue(0x00FF00);
        else if (self instanceof class_1542) cir.setReturnValue(0xFFFF00);
    }
}
