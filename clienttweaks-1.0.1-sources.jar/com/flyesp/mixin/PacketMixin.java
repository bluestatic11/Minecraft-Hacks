package com.flyesp.mixin;

import com.flyesp.FakeLag;
import com.flyesp.FlyEspModClient;
import net.minecraft.class_2596;
import net.minecraft.class_2842;
import net.minecraft.class_8673;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_8673.class, priority = 1500)
public abstract class PacketMixin {
    @Inject(method = "send", at = @At("HEAD"), cancellable = true, require = 0)
    private void onSend(class_2596<?> packet, CallbackInfo ci) {
        if (FakeLag.sendDirect) return;
        if (packet instanceof class_2842 && FlyEspModClient.flyEnabled) {
            ci.cancel();
            return;
        }
        if (FlyEspModClient.fakeLagEnabled && FakeLag.shouldDelay(packet)) {
            FakeLag.queuePacket(packet);
            ci.cancel();
        }
    }
}
