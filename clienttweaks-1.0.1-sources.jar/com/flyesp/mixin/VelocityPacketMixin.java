package com.flyesp.mixin;

import com.flyesp.FlyEspModClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_2664;
import net.minecraft.class_2743;
import net.minecraft.class_310;
import net.minecraft.class_634;

/**
 * Intercepts server-side velocity/knockback packets.
 * This is where the REAL knockback comes from on servers.
 */
@Mixin(value = class_634.class, priority = 1500)
public abstract class VelocityPacketMixin {

    @Inject(method = "handleSetEntityMotion", at = @At("HEAD"), cancellable = true, require = 0)
    private void onVelocityPacket(class_2743 packet, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        // Only cancel if this packet is for our player
        if (packet.method_11818() != mc.field_1724.method_5628()) return;

        // Full anti-KB — cancel entirely
        if (FlyEspModClient.antiKBEnabled) {
            ci.cancel();
            return;
        }

        // Velocity mode — let it through but we'll reduce it after
        if (FlyEspModClient.velocityEnabled) {
            ci.cancel();
            // Apply reduced velocity manually
            double reduction = 0.80 + ThreadLocalRandom.current().nextDouble() * 0.10;
            double remaining = 1.0 - reduction;
            net.minecraft.class_243 vel = packet.method_73085();
            mc.field_1724.method_18800(vel.field_1352 * remaining, vel.field_1351 * remaining, vel.field_1350 * remaining);
        }
    }

    @Inject(method = "handleExplosion", at = @At("HEAD"), cancellable = true, require = 0)
    private void onExplosionPacket(class_2664 packet, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        if (FlyEspModClient.antiKBEnabled) {
            ci.cancel();
        }
    }
}
