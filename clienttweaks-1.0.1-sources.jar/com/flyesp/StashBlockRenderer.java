package com.flyesp;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class StashBlockRenderer {
    private static final List<class_2338> stashPositions = new CopyOnWriteArrayList<>();
    private static int scanCooldown = 0;
    public static int getCount() { return stashPositions.size(); }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!FlyEspModClient.espEnabled || client.field_1724 == null || client.field_1687 == null) {
                stashPositions.clear(); return;
            }
            if (--scanCooldown > 0) return;
            scanCooldown = 40;
            List<class_2338> found = new ArrayList<>();
            class_2338 pp = client.field_1724.method_24515();
            int chunkRange = 3;
            int pcx = pp.method_10263() >> 4, pcz = pp.method_10260() >> 4;
            for (int cx = pcx - chunkRange; cx <= pcx + chunkRange; cx++)
                for (int cz = pcz - chunkRange; cz <= pcz + chunkRange; cz++) {
                    if (!client.field_1687.method_8393(cx, cz)) continue;
                    class_2818 chunk = client.field_1687.method_8497(cx, cz);
                    class_2826[] sections = chunk.method_12006();
                    for (int si = 0; si < sections.length; si++) {
                        class_2826 section = sections[si];
                        if (section == null || section.method_38292()) continue;
                        int baseY = client.field_1687.method_31607() + (si * 16);
                        for (int x = 0; x < 16; x++)
                            for (int y = 0; y < 16; y++)
                                for (int z = 0; z < 16; z++) {
                                    class_2680 state = section.method_12254(x, y, z);
                                    if (XrayHelper.isStashBlock(state.method_26204()))
                                        found.add(new class_2338(cx * 16 + x, baseY + y, cz * 16 + z));
                                }
                    }
                }
            stashPositions.clear(); stashPositions.addAll(found);
        });
    }
}
