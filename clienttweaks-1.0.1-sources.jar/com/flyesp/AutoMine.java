package com.flyesp;

import java.util.*;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;

public class AutoMine {
    private static final double REACH = 4.5;
    private static class_2338 currentTarget = null;
    private static class_2350 currentFace = null;
    private static boolean miningStarted = false;
    private static int scanCooldown = 0;

    // Free mine tracking
    private static class_2338 freeMineTarget = null;
    private static class_2350 freeMineFace = null;
    private static boolean freeMineStarted = false;

    private static int presetIndex = 0;
    private static final String[] PRESET_NAMES = {
            "Free Mine", "All Ores", "Diamonds Only", "Ancient Debris", "Iron+Gold+Diamond", "Emeralds", "Coal+Iron"
    };
    private static final List<Set<class_2248>> PRESETS = new ArrayList<>();

    static {
        PRESETS.add(null); // Free mine

        Set<class_2248> all = new HashSet<>();
        all.add(class_2246.field_10418); all.add(class_2246.field_29219);
        all.add(class_2246.field_10212); all.add(class_2246.field_29027);
        all.add(class_2246.field_10571); all.add(class_2246.field_29026);
        all.add(class_2246.field_10442); all.add(class_2246.field_29029);
        all.add(class_2246.field_10013); all.add(class_2246.field_29220);
        all.add(class_2246.field_10090); all.add(class_2246.field_29028);
        all.add(class_2246.field_10080); all.add(class_2246.field_29030);
        all.add(class_2246.field_27120); all.add(class_2246.field_29221);
        all.add(class_2246.field_23077); all.add(class_2246.field_10213);
        all.add(class_2246.field_22109);
        PRESETS.add(all);

        Set<class_2248> diamonds = new HashSet<>();
        diamonds.add(class_2246.field_10442); diamonds.add(class_2246.field_29029);
        PRESETS.add(diamonds);

        Set<class_2248> debris = new HashSet<>();
        debris.add(class_2246.field_22109);
        PRESETS.add(debris);

        Set<class_2248> igd = new HashSet<>();
        igd.add(class_2246.field_10212); igd.add(class_2246.field_29027);
        igd.add(class_2246.field_10571); igd.add(class_2246.field_29026);
        igd.add(class_2246.field_10442); igd.add(class_2246.field_29029);
        PRESETS.add(igd);

        Set<class_2248> emeralds = new HashSet<>();
        emeralds.add(class_2246.field_10013); emeralds.add(class_2246.field_29220);
        PRESETS.add(emeralds);

        Set<class_2248> ci = new HashSet<>();
        ci.add(class_2246.field_10418); ci.add(class_2246.field_29219);
        ci.add(class_2246.field_10212); ci.add(class_2246.field_29027);
        PRESETS.add(ci);
    }

    public static String getCurrentPresetName() { return PRESET_NAMES[presetIndex]; }

    public static void cyclePreset() {
        presetIndex = (presetIndex + 1) % PRESETS.size();
        currentTarget = null; miningStarted = false;
        freeMineTarget = null; freeMineStarted = false;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null)
            mc.field_1724.method_7353(class_2561.method_43470("\u00A76[AutoMine] \u00A7aMode: \u00A7f" + PRESET_NAMES[presetIndex]), false);
    }

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1687 == null || mc.field_1755 != null) return;

        Set<class_2248> targets = PRESETS.get(presetIndex);
        if (targets == null) tickFreeMine(mc, mc.field_1724);
        else tickOreMine(mc, mc.field_1724, targets);
    }

    private static void tickFreeMine(class_310 mc, class_746 player) {
        if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1332) {
            freeMineTarget = null; freeMineStarted = false;
            return;
        }

        class_3965 blockHit = (class_3965) mc.field_1765;
        class_2338 pos = blockHit.method_17777();
        class_2350 face = blockHit.method_17780();
        class_2680 state = mc.field_1687.method_8320(pos);

        if (state.method_26215()) return;
        if (state.method_26214(mc.field_1687, pos) < 0) return;

        // New block — start mining
        if (!pos.equals(freeMineTarget) || !face.equals(freeMineFace)) {
            freeMineTarget = pos;
            freeMineFace = face;
            freeMineStarted = false;
        }

        if (!freeMineStarted) {
            mc.field_1761.method_2910(pos, face);
            freeMineStarted = true;
        } else {
            mc.field_1761.method_2902(pos, face);
        }
    }

    private static void tickOreMine(class_310 mc, class_746 player, Set<class_2248> targets) {
        // Check if current target is still valid
        if (currentTarget != null) {
            class_2248 block = mc.field_1687.method_8320(currentTarget).method_26204();
            double dist = Math.sqrt(player.method_24515().method_10262(currentTarget));
            if (!targets.contains(block) || dist > REACH) {
                currentTarget = null; miningStarted = false;
            }
        }

        // Scan for new target
        if (currentTarget == null) {
            if (--scanCooldown > 0) return;
            scanCooldown = 5;
            currentTarget = findNearestOre(mc, player, targets);
            if (currentTarget == null) return;
            currentFace = getClosestFace(player, currentTarget);
            miningStarted = false;
        }

        // Rotate toward target
        rotateToward(player, currentTarget);

        // Start mining once, then continue
        if (!miningStarted) {
            mc.field_1761.method_2910(currentTarget, currentFace);
            miningStarted = true;
        } else {
            mc.field_1761.method_2902(currentTarget, currentFace);
        }
    }

    private static class_2338 findNearestOre(class_310 mc, class_746 player, Set<class_2248> targets) {
        class_2338 pp = player.method_24515();
        int range = (int) REACH + 1;
        class_2338 best = null;
        double bestDist = Double.MAX_VALUE;
        for (int x = -range; x <= range; x++)
            for (int y = -range; y <= range; y++)
                for (int z = -range; z <= range; z++) {
                    class_2338 pos = pp.method_10069(x, y, z);
                    if (!targets.contains(mc.field_1687.method_8320(pos).method_26204())) continue;
                    double dist = player.method_5836(1.0f).method_1028(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
                    if (dist < bestDist && dist <= REACH * REACH) { best = pos; bestDist = dist; }
                }
        return best;
    }

    private static void rotateToward(class_746 player, class_2338 target) {
        class_243 eyes = player.method_5836(1.0f);
        class_243 center = new class_243(target.method_10263() + 0.5, target.method_10264() + 0.5, target.method_10260() + 0.5);
        class_243 diff = center.method_1020(eyes);
        float targetYaw = (float) Math.toDegrees(Math.atan2(-diff.field_1352, diff.field_1350));
        float targetPitch = (float) Math.toDegrees(-Math.atan2(diff.field_1351, Math.sqrt(diff.field_1352 * diff.field_1352 + diff.field_1350 * diff.field_1350)));
        float yawDiff = wrapDegrees(targetYaw - player.method_36454());
        float pitchDiff = targetPitch - player.method_36455();
        float speed = 15f;
        player.method_36456(player.method_36454() + Math.max(-speed, Math.min(speed, yawDiff)));
        player.method_36457(Math.max(-90f, Math.min(90f, player.method_36455() + Math.max(-speed, Math.min(speed, pitchDiff)))));
    }

    private static class_2350 getClosestFace(class_746 player, class_2338 target) {
        class_243 eyes = player.method_5836(1.0f);
        double dx = eyes.field_1352 - (target.method_10263() + 0.5), dy = eyes.field_1351 - (target.method_10264() + 0.5), dz = eyes.field_1350 - (target.method_10260() + 0.5);
        double ax = Math.abs(dx), ay = Math.abs(dy), az = Math.abs(dz);
        if (ax >= ay && ax >= az) return dx > 0 ? class_2350.field_11034 : class_2350.field_11039;
        if (ay >= ax && ay >= az) return dy > 0 ? class_2350.field_11036 : class_2350.field_11033;
        return dz > 0 ? class_2350.field_11035 : class_2350.field_11043;
    }

    private static float wrapDegrees(float deg) {
        deg = deg % 360; if (deg >= 180) deg -= 360; if (deg < -180) deg += 360; return deg;
    }
}
