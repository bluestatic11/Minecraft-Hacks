package com.flyesp;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3966;

/**
 * Humanized Auto Clicker — randomized CPS with natural variation.
 *
 * Instead of constant 50 CPS (instant ban), uses:
 * - Base CPS of 10-14 (legit butterfly/jitter click range)
 * - Random variance per click (+/- 2 CPS)
 * - Occasional micro-pauses (simulates finger fatigue)
 * - Never sends more than 1 attack per tick
 */
public class AutoClicker {
    private static int baseCps = 12;
    private static int ticksUntilNextClick = 0;
    private static int clickCount = 0;

    public static int getCps() { return baseCps; }
    public static void setCps(int newCps) { baseCps = Math.max(6, Math.min(18, newCps)); }

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1755 != null) return;

        if (ticksUntilNextClick > 0) {
            ticksUntilNextClick--;
            return;
        }

        doClick(mc);
        clickCount++;

        // Randomized delay until next click
        int currentCps = baseCps + ThreadLocalRandom.current().nextInt(-2, 3); // +/- 2
        currentCps = Math.max(6, Math.min(16, currentCps));
        ticksUntilNextClick = Math.max(1, 20 / currentCps);

        // Add extra random tick sometimes (jitter)
        if (ThreadLocalRandom.current().nextInt(100) < 25) {
            ticksUntilNextClick += 1;
        }

        // Every 30-60 clicks, simulate a micro-pause (finger fatigue)
        if (clickCount > 30 + ThreadLocalRandom.current().nextInt(30)) {
            ticksUntilNextClick += ThreadLocalRandom.current().nextInt(3, 8);
            clickCount = 0;
        }
    }

    private static void doClick(class_310 mc) {
        if (mc.field_1765 == null) return;
        switch (mc.field_1765.method_17783()) {
            case field_1331:
                class_3966 ehr = (class_3966) mc.field_1765;
                mc.field_1761.method_2918(mc.field_1724, ehr.method_17782());
                mc.field_1724.method_6104(class_1268.field_5808);
                break;
            case field_1332:
                class_304.method_1420(mc.field_1690.field_1886.method_1429());
                break;
            case field_1333:
                mc.field_1724.method_6104(class_1268.field_5808);
                break;
        }
    }
}
