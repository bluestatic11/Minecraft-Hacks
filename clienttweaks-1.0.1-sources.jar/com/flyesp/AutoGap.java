package com.flyesp;

import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Auto Gap — automatically eats golden apples when health is low.
 *
 * - Eats enchanted golden apple (notch apple) first if available
 * - Falls back to regular golden apple
 * - Triggers at 8 hearts (16 HP) or below
 * - Swaps gap to hand, eats, swaps back
 * - Won't eat if already eating or in a GUI
 */
public class AutoGap {
    private static int cooldown = 0;
    private static boolean isEating = false;
    private static int previousSlot = -1;
    private static int eatTicks = 0;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1755 != null) return;

        if (cooldown > 0) { cooldown--; return; }

        class_746 player = mc.field_1724;

        // If currently eating, hold right click
        if (isEating) {
            tickEating(mc, player);
            return;
        }

        // Check every 10 ticks
        cooldown = 10;

        // Only eat when health is at or below 8 hearts
        if (player.method_6032() > 16.0f) return;

        // Don't eat if already at full absorption (notch apple active)
        if (player.method_6067() > 4.0f) return;

        // Find a golden apple
        class_1661 inv = player.method_31548();
        int gapSlot = findGoldenApple(inv);
        if (gapSlot == -1) return;

        // Swap to hand and start eating
        previousSlot = inv.method_67532();

        if (gapSlot >= 36 && gapSlot <= 44) {
            inv.method_61496(gapSlot - 36);
        } else {
            mc.field_1761.method_2906(
                    player.field_7512.field_7763, gapSlot, 0, class_1713.field_7790, player);
            mc.field_1761.method_2906(
                    player.field_7512.field_7763, 36 + inv.method_67532(), 0, class_1713.field_7790, player);
            mc.field_1761.method_2906(
                    player.field_7512.field_7763, gapSlot, 0, class_1713.field_7790, player);
        }

        isEating = true;
        eatTicks = 0;
        cooldown = 2;
    }

    private static void tickEating(class_310 mc, class_746 player) {
        class_1799 held = player.method_6047();

        // Check if we're still holding a gap
        if (!held.method_31574(class_1802.field_8463) && !held.method_31574(class_1802.field_8367)) {
            stopEating(mc, player);
            return;
        }

        // Use item (hold right click)
        mc.field_1761.method_2919(player, class_1268.field_5808);

        eatTicks++;

        // Eating takes 32 ticks (1.6 seconds), wait a bit extra
        if (eatTicks > 40 || player.method_6032() > 16.0f) {
            stopEating(mc, player);
        }
    }

    private static void stopEating(class_310 mc, class_746 player) {
        isEating = false;
        eatTicks = 0;
        if (previousSlot >= 0 && previousSlot < 9) {
            player.method_31548().method_61496(previousSlot);
        }
        previousSlot = -1;
        cooldown = 20; // 1 second before checking again
    }

    /**
     * Find golden apple in inventory. Prefers enchanted (notch) apples.
     */
    private static int findGoldenApple(class_1661 inv) {
        int regularSlot = -1;

        // Check hotbar first
        for (int i = 0; i < 9; i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_31574(class_1802.field_8367)) return 36 + i;
            if (stack.method_31574(class_1802.field_8463) && regularSlot == -1) regularSlot = 36 + i;
        }

        // Check main inventory
        for (int i = 9; i < 36; i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_31574(class_1802.field_8367)) return i;
            if (stack.method_31574(class_1802.field_8463) && regularSlot == -1) regularSlot = i;
        }

        return regularSlot;
    }
}
