package com.flyesp;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_746;

/**
 * Improved Stealth Flight — harder to detect movement patterns.
 *
 * - Acceleration/deceleration instead of instant max speed
 * - Slight random drift when hovering (no player is perfectly still)
 * - Anti-kick drops more frequently with random timing
 * - Speed varies slightly each tick
 * - Smoother vertical movement
 */
public class StealthFly {
    private static final double MAX_SPEED = 0.45;
    private static final double VERTICAL_SPEED = 0.35;
    private static final double ACCELERATION = 0.12;
    private static int antiKickTimer = 0;
    private static int antiKickInterval = 50;
    private static double currentSpeedX = 0;
    private static double currentSpeedZ = 0;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        class_746 player = mc.field_1724;
        class_315 options = mc.field_1690;
        if (player.method_68878() || player.method_7325()) return;

        player.field_6017 = 0;

        // Calculate target velocity from input
        double targetX = 0, targetZ = 0, motionY = 0;
        float yaw = player.method_36454();
        double rad = Math.toRadians(yaw);

        // Slight speed variance each tick (human-like)
        double speedMult = 0.95 + ThreadLocalRandom.current().nextDouble() * 0.1;

        if (options.field_1894.method_1434()) { targetX -= Math.sin(rad) * MAX_SPEED * speedMult; targetZ += Math.cos(rad) * MAX_SPEED * speedMult; }
        if (options.field_1881.method_1434()) { targetX += Math.sin(rad) * MAX_SPEED * speedMult; targetZ -= Math.cos(rad) * MAX_SPEED * speedMult; }
        if (options.field_1913.method_1434()) { targetX += Math.cos(rad) * MAX_SPEED * speedMult; targetZ += Math.sin(rad) * MAX_SPEED * speedMult; }
        if (options.field_1849.method_1434()) { targetX -= Math.cos(rad) * MAX_SPEED * speedMult; targetZ -= Math.sin(rad) * MAX_SPEED * speedMult; }

        // Smooth acceleration/deceleration instead of instant speed
        currentSpeedX += (targetX - currentSpeedX) * ACCELERATION;
        currentSpeedZ += (targetZ - currentSpeedZ) * ACCELERATION;

        // Add tiny random drift when hovering (no real player is perfectly still)
        if (targetX == 0 && targetZ == 0) {
            currentSpeedX += (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.003;
            currentSpeedZ += (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.003;
        }

        // Vertical movement with slight smoothing
        if (options.field_1903.method_1434()) motionY = VERTICAL_SPEED * speedMult;
        else if (options.field_1832.method_1434()) motionY = -VERTICAL_SPEED * speedMult;
        else motionY = (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.005; // Tiny hover jitter

        // Anti-kick: drop at randomized intervals (40-65 ticks)
        antiKickTimer++;
        if (antiKickTimer >= antiKickInterval) {
            antiKickTimer = 0;
            antiKickInterval = 40 + ThreadLocalRandom.current().nextInt(25);
            motionY = -0.08 - ThreadLocalRandom.current().nextDouble() * 0.03; // Random drop amount
        }

        player.method_18799(new class_243(currentSpeedX, motionY, currentSpeedZ));
        player.method_5875(true);
    }

    public static void disable() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        mc.field_1724.method_5875(false);
        mc.field_1724.field_6017 = 0;
        antiKickTimer = 0;
        currentSpeedX = 0;
        currentSpeedZ = 0;
    }
}
