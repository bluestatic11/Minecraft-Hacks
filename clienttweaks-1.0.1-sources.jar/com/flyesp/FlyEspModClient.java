package com.flyesp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1923;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import java.util.List;
import java.util.Map;

public class FlyEspModClient implements ClientModInitializer {
    public static boolean flyEnabled = false;
    public static boolean espEnabled = false;
    public static boolean xrayEnabled = false;
    public static boolean oreFinderEnabled = false;
    public static boolean seedCrackerEnabled = false;
    public static boolean autoTotemEnabled = false;
    public static boolean autoClickerEnabled = false;
    public static boolean triggerBotEnabled = false;
    public static boolean autoSprintEnabled = false;
    public static boolean noFallEnabled = false;
    public static boolean fakeLagEnabled = false;
    public static boolean aimAssistEnabled = false;
    public static boolean baseFinderEnabled = false;
    public static boolean antiKBEnabled = false;
    public static boolean autoXPEnabled = false;
    public static boolean autoMineEnabled = false;
    public static boolean reachEnabled = false;
    public static boolean velocityEnabled = false;
    public static boolean autoGapEnabled = false;
    public static boolean radarEnabled = false;
    public static boolean autoToolEnabled = false;
    public static boolean safeAnchorEnabled = false;
    public static boolean autoCrystalEnabled = false;
    public static boolean vanishDetectEnabled = false;
    public static boolean hudVisible = true; // Visible by default, press \ to hide

    @Override
    public void onInitializeClient() {
        KeyBindings.register();
        StashBlockRenderer.register();
        OreRenderer.register();
        BaseFinder.register();
        AimAssist.registerFrameHandler();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;

            // Toggle fly (])
            while (KeyBindings.FLY_TOGGLE.method_1436()) {
                flyEnabled = !flyEnabled;
                if (!flyEnabled) StealthFly.disable();
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Fly: " + (flyEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle ESP (F8)
            while (KeyBindings.ESP_TOGGLE.method_1436()) {
                espEnabled = !espEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("ESP: " + (espEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle X-ray (X)
            while (KeyBindings.XRAY_TOGGLE.method_1436()) {
                xrayEnabled = !xrayEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("X-Ray: " + (xrayEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
                try { client.field_1769.method_3279(); } catch (Exception ignored) {}
            }

            // Toggle Ore Finder (Z)
            while (KeyBindings.ORE_FINDER_TOGGLE.method_1436()) {
                oreFinderEnabled = !oreFinderEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Ore Finder: " + (oreFinderEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
                if (!oreFinderEnabled) AntiAntiXray.clearConfirmed();
            }

            // Toggle Seed Cracker (F9)
            while (KeyBindings.SEED_CRACKER_TOGGLE.method_1436()) {
                if (SeedCracker.getStatus() == SeedCracker.Status.FOUND) {
                    SeedCracker.copySeedToClipboard();
                } else {
                    seedCrackerEnabled = !seedCrackerEnabled;
                    if (seedCrackerEnabled) {
                        SeedCracker.enable();
                        if (hudVisible) client.field_1724.method_7353(
                                class_2561.method_43470("\u00A76[SeedCracker] \u00A7aEnabled \u2014 explore to find structures!"), false);
                    } else {
                        SeedCracker.reset();
                        if (hudVisible) client.field_1724.method_7353(
                                class_2561.method_43470("\u00A76[SeedCracker] \u00A7cDisabled and reset"), false);
                    }
                }
            }

            // Toggle Auto Totem (V)
            while (KeyBindings.AUTO_TOTEM_TOGGLE.method_1436()) {
                autoTotemEnabled = !autoTotemEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Auto Totem: " + (autoTotemEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle Auto Clicker (F4)
            while (KeyBindings.AUTO_CLICKER_TOGGLE.method_1436()) {
                autoClickerEnabled = !autoClickerEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Auto Clicker: " + (autoClickerEnabled ? "\u00A7aON \u00A77(" + AutoClicker.getCps() + " CPS)" : "\u00A7cOFF")), true);
            }

            // Toggle Trigger Bot (F1)
            while (KeyBindings.TRIGGER_BOT_TOGGLE.method_1436()) {
                triggerBotEnabled = !triggerBotEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Trigger Bot: " + (triggerBotEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle Auto Sprint (F2)
            while (KeyBindings.AUTO_SPRINT_TOGGLE.method_1436()) {
                autoSprintEnabled = !autoSprintEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Auto Sprint: " + (autoSprintEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle No Fall (F3)
            while (KeyBindings.NO_FALL_TOGGLE.method_1436()) {
                noFallEnabled = !noFallEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("No Fall: " + (noFallEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle Fake Lag (F5)
            while (KeyBindings.FAKE_LAG_TOGGLE.method_1436()) {
                fakeLagEnabled = !fakeLagEnabled;
                if (!fakeLagEnabled) FakeLag.flush();
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Fake Lag: " + (fakeLagEnabled ? "\u00A7aON \u00A77(400ms)" : "\u00A7cOFF")), true);
            }

            // Toggle Aim Assist (F6)
            while (KeyBindings.AIM_ASSIST_TOGGLE.method_1436()) {
                aimAssistEnabled = !aimAssistEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Aim Assist: " + (aimAssistEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle Base Finder (B)
            while (KeyBindings.BASE_FINDER_TOGGLE.method_1436()) {
                baseFinderEnabled = !baseFinderEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Base Finder: " + (baseFinderEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle Anti-KB (F7)
            while (KeyBindings.ANTI_KB_TOGGLE.method_1436()) {
                antiKBEnabled = !antiKBEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Anti-KB: " + (antiKBEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle Auto XP (N)
            while (KeyBindings.AUTO_XP_TOGGLE.method_1436()) {
                autoXPEnabled = !autoXPEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Auto XP: " + (autoXPEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle Auto Mine (M) — sneak+M cycles ore presets
            while (KeyBindings.AUTO_MINE_TOGGLE.method_1436()) {
                if (client.field_1724.method_5715()) {
                    AutoMine.cyclePreset();
                } else {
                    autoMineEnabled = !autoMineEnabled;
                    if (hudVisible) client.field_1724.method_7353(
                            class_2561.method_43470("Auto Mine: " + (autoMineEnabled ?
                                    "\u00A7aON \u00A77(" + AutoMine.getCurrentPresetName() + ")" : "\u00A7cOFF")), true);
                }
            }

            // Toggle Reach (F10)
            while (KeyBindings.REACH_TOGGLE.method_1436()) {
                reachEnabled = !reachEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Reach: " + (reachEnabled ? "\u00A7aON \u00A77(3.1-3.3)" : "\u00A7cOFF")), true);
            }

            // Toggle Velocity (F11)
            while (KeyBindings.VELOCITY_TOGGLE.method_1436()) {
                velocityEnabled = !velocityEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Velocity: " + (velocityEnabled ? "\u00A7aON \u00A77(80-90%)" : "\u00A7cOFF")), true);
            }

            // Toggle Auto Gap (G)
            while (KeyBindings.AUTO_GAP_TOGGLE.method_1436()) {
                autoGapEnabled = !autoGapEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Auto Gap: " + (autoGapEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle Radar (R)
            while (KeyBindings.RADAR_TOGGLE.method_1436()) {
                radarEnabled = !radarEnabled;
                if (!radarEnabled) RadarScanner.reset();
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Radar: " + (radarEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            if (autoXPEnabled) AutoXP.tick();
            if (autoMineEnabled) AutoMine.tick();
            // Toggle Auto Tool (T)
            while (KeyBindings.AUTO_TOOL_TOGGLE.method_1436()) {
                autoToolEnabled = !autoToolEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Auto Tool: " + (autoToolEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            if (autoGapEnabled) AutoGap.tick();
            if (radarEnabled) RadarScanner.tick();
            // Toggle Safe Anchor (Y)
            while (KeyBindings.SAFE_ANCHOR_TOGGLE.method_1436()) {
                safeAnchorEnabled = !safeAnchorEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Safe Anchor: " + (safeAnchorEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            // Toggle Vanish Detector (K)
            while (KeyBindings.VANISH_DETECT_TOGGLE.method_1436()) {
                vanishDetectEnabled = !vanishDetectEnabled;
                if (!vanishDetectEnabled) VanishDetector.reset();
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Vanish Detect: " + (vanishDetectEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            if (autoToolEnabled) AutoTool.tick();
            if (vanishDetectEnabled) VanishDetector.tick();
            // Toggle Auto Crystal (U)
            while (KeyBindings.AUTO_CRYSTAL_TOGGLE.method_1436()) {
                autoCrystalEnabled = !autoCrystalEnabled;
                if (hudVisible) client.field_1724.method_7353(
                        class_2561.method_43470("Auto Crystal: " + (autoCrystalEnabled ? "\u00A7aON" : "\u00A7cOFF")), true);
            }

            if (safeAnchorEnabled) AutoSafeAnchor.tick();
            if (autoCrystalEnabled) AutoCrystal.tick();
            // Panic Button (End) — kills everything instantly
            while (KeyBindings.PANIC.method_1436()) {
                PanicButton.toggle();
            }

            // HUD Toggle (\)
            if (KeyBindings.HUD_TOGGLE.method_1436()) {
                hudVisible = !hudVisible;
                client.field_1724.method_7353(
                        class_2561.method_43470("HUD: " + (hudVisible ? "\u00A7aVisible" : "\u00A7cHidden")), true);
            }

            // If panicked, skip all hack processing
            if (PanicButton.isPanicked()) return;

            // Gamemode Switcher (F12)
            while (KeyBindings.GAMEMODE_SWITCH.method_1436()) {
                GameModeSwitcher.cycle();
            }

            if (aimAssistEnabled) AimAssist.tick();
            if (seedCrackerEnabled) SeedCracker.tick();
            if (autoSprintEnabled) AutoSprint.tick();
            if (noFallEnabled) NoFall.tick();
            if (fakeLagEnabled) FakeLag.tick();
            else if (FakeLag.hasQueued()) FakeLag.flush(); // Drain remaining packets gradually
            if (autoTotemEnabled) AutoTotem.tick();
            if (autoClickerEnabled) AutoClicker.tick();
            if (triggerBotEnabled) TriggerBot.tick();
            if (flyEnabled) StealthFly.tick();
        });

        // HUD overlay
        HudRenderCallback.EVENT.register((class_332 gfx, class_9779 dt) -> {
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 == null || !hudVisible) return;

            int y = 4;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A78[CT]"), 4, y, 0xFFFFFF);
            y += 12;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7bFly []]: " + (flyEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7dESP [F9]: " + (espEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7eX-Ray [X]: " + (xrayEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7aOre Finder [Z]: " + (oreFinderEnabled ? "\u00A7aON \u00A77(" + OreRenderer.getLastOreCount() + " ores)" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A75Trigger Bot [F1]: " + (triggerBotEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A74Auto Click [F4]: " + (autoClickerEnabled ? "\u00A7aON \u00A77(" + AutoClicker.getCps() + " CPS)" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7cAuto Totem [V]: " + (autoTotemEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7dAuto Crystal [U]: " + (autoCrystalEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A74Safe Anchor [Y]: " + (safeAnchorEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7fAuto Tool [J]: " + (autoToolEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7dReach [F10]: " + (reachEnabled ? "\u00A7aON \u00A77(3.1-3.3)" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A75Velocity [F11]: " + (velocityEnabled ? "\u00A7aON \u00A77(80-90%)" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A76Auto Gap [C]: " + (autoGapEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A73Radar [R]: " + (radarEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7aAuto Mine [M]: " + (autoMineEnabled ? "\u00A7aON \u00A77(" + AutoMine.getCurrentPresetName() + ")" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7bAuto XP [N]: " + (autoXPEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A74Anti-KB [F7]: " + (antiKBEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7eBase Finder [B]: " + (baseFinderEnabled ? "\u00A7aON \u00A77(" + BaseFinder.getLastCount() + " blocks)" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A79Aim Assist [F8]: " + (aimAssistEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A78Fake Lag [F5]: " + (fakeLagEnabled ? "\u00A7aON \u00A77(400ms)" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A76No Fall [F3]: " + (noFallEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A72Auto Sprint [H]: " + (autoSprintEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;
            gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A73Seed Cracker [F6]: " + (seedCrackerEnabled ? "\u00A7aON" : "\u00A7cOFF")), 4, y, 0xFFFFFF);
            y += 10;

            if (seedCrackerEnabled) {
                SeedCracker.Status status = SeedCracker.getStatus();
                if (status == SeedCracker.Status.FOUND) {
                    gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7a\u00A7lSEED: \u00A7b" + SeedCracker.getCrackedSeed()), 4, y, 0xFFFFFF);
                    y += 10;
                    gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A77Press F9 to copy to clipboard"), 4, y, 0xFFFFFF);
                    y += 10;
                } else if (status == SeedCracker.Status.CRACKING) {
                    gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A7eCracking... " + SeedCracker.getCrackProgress() + "%"), 4, y, 0xFFFFFF);
                    y += 10;
                } else {
                    gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A77Collecting data... explore structures!"), 4, y, 0xFFFFFF);
                    y += 10;
                }
                Map<StructureData.StructureType, List<class_1923>> structures = SeedCracker.getFoundStructures();
                for (Map.Entry<StructureData.StructureType, List<class_1923>> entry : structures.entrySet()) {
                    gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A77  " + entry.getKey().displayName + ": \u00A7f" + entry.getValue().size()), 4, y, 0xFFFFFF);
                    y += 9;
                }
                int biomes = SeedCracker.getBiomeSampleCount();
                if (biomes > 0) {
                    gfx.method_27535(mc.field_1772, class_2561.method_43470("\u00A77  Biome samples: \u00A7f" + biomes), 4, y, 0xFFFFFF);
                }
            }
        });
    }
}
