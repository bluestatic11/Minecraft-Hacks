package com.flyesp;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_7924;

public class SeedCracker {
    public enum Status { IDLE, COLLECTING, CRACKING, FOUND }

    private static final AtomicReference<Status> status = new AtomicReference<>(Status.IDLE);
    private static final AtomicLong crackedSeed = new AtomicLong(0);
    private static final AtomicLong crackProgress = new AtomicLong(0);
    private static final Map<StructureData.StructureType, List<class_1923>> foundStructures = new ConcurrentHashMap<>();
    private static final Map<class_2338, String> biomeSamples = new ConcurrentHashMap<>();
    private static final Set<class_1923> scannedChunks = ConcurrentHashMap.newKeySet();
    private static Thread crackThread = null;
    private static volatile boolean cancelCrack = false;
    private static int tickCounter = 0;
    private static class_2338 lastBiomeSamplePos = null;

    public static Status getStatus() { return status.get(); }
    public static long getCrackedSeed() { return crackedSeed.get(); }
    public static long getCrackProgress() { return crackProgress.get(); }
    public static Map<StructureData.StructureType, List<class_1923>> getFoundStructures() { return Collections.unmodifiableMap(foundStructures); }
    public static int getBiomeSampleCount() { return biomeSamples.size(); }

    public static void reset() {
        cancelCrack = true;
        if (crackThread != null) crackThread.interrupt();
        crackThread = null;
        foundStructures.clear(); biomeSamples.clear(); scannedChunks.clear();
        status.set(Status.IDLE); crackedSeed.set(0); crackProgress.set(0); cancelCrack = false;
    }

    public static void enable() { if (status.get() == Status.IDLE) status.set(Status.COLLECTING); }

    public static void tick() {
        if (status.get() != Status.COLLECTING) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        tickCounter++;
        if (tickCounter % 40 == 0) scanForStructures(mc);
        if (tickCounter % 20 == 0) collectBiomeSample(mc);
        if (tickCounter % 100 == 0) checkAndStartCracking();
    }

    private static void scanForStructures(class_310 mc) {
        class_638 level = mc.field_1687;
        class_2338 pp = mc.field_1724.method_24515();
        class_1923 cp = new class_1923(pp);
        if (scannedChunks.contains(cp)) return;
        scannedChunks.add(cp);

        int r = 24, bell = 0, blueTerra = 0, sandstone = 0, mossy = 0, chiseled = 0, spruce = 0, prismarine = 0, darkOak = 0, cobble = 0;
        boolean swamp = false;
        class_1959 biome = level.method_23753(pp).comp_349();
        String bn = level.method_30349().method_30530(class_7924.field_41236).method_10221(biome).toString();
        if (bn.contains("swamp")) swamp = true;

        for (int x = -r; x <= r; x += 2) for (int z = -r; z <= r; z += 2) for (int y = -10; y <= 15; y += 2) {
            class_2248 b = level.method_8320(pp.method_10069(x, y, z)).method_26204();
            if (b == class_2246.field_16332) bell++;
            if (b == class_2246.field_10409) blueTerra++;
            if (b == class_2246.field_9979 || b == class_2246.field_10361 || b == class_2246.field_10467) sandstone++;
            if (b == class_2246.field_9989) mossy++;
            if (b == class_2246.field_10552) chiseled++;
            if (b == class_2246.field_9975) spruce++;
            if (b == class_2246.field_10135 || b == class_2246.field_10006 || b == class_2246.field_10297) prismarine++;
            if (b == class_2246.field_10010 || b == class_2246.field_10075) darkOak++;
            if (b == class_2246.field_10445) cobble++;
        }

        StructureData.StructureType detected = null;
        if (bell >= 1) detected = StructureData.StructureType.VILLAGE;
        else if (blueTerra >= 4 && sandstone >= 20) detected = StructureData.StructureType.DESERT_PYRAMID;
        else if (chiseled >= 2 && mossy >= 10 && cobble >= 30) detected = StructureData.StructureType.JUNGLE_PYRAMID;
        else if (swamp && spruce >= 5 && spruce <= 30) detected = StructureData.StructureType.SWAMP_HUT;
        else if (prismarine >= 30) detected = StructureData.StructureType.OCEAN_MONUMENT;
        else if (darkOak >= 50) detected = StructureData.StructureType.WOODLAND_MANSION;

        if (detected != null) addStructure(detected, cp, mc);
    }

    private static void addStructure(StructureData.StructureType type, class_1923 chunk, class_310 mc) {
        List<class_1923> list = foundStructures.computeIfAbsent(type, k -> new CopyOnWriteArrayList<>());
        int[] reg = StructureData.getRegion(type, chunk.field_9181, chunk.field_9180);
        for (class_1923 ex : list) { int[] er = StructureData.getRegion(type, ex.field_9181, ex.field_9180); if (er[0] == reg[0] && er[1] == reg[1]) return; }
        list.add(chunk);
        if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470(
                "\u00A76[SeedCracker] \u00A7aFound " + type.displayName + " at [" + chunk.field_9181 + "," + chunk.field_9180 + "] (" + list.size() + " total)"), false);
    }

    private static void collectBiomeSample(class_310 mc) {
        class_2338 pos = mc.field_1724.method_24515();
        if (lastBiomeSamplePos != null && Math.sqrt(pos.method_10262(lastBiomeSamplePos)) < 80) return;
        lastBiomeSamplePos = pos;
        class_1959 biome = mc.field_1687.method_23753(pos).comp_349();
        String name = mc.field_1687.method_30349().method_30530(class_7924.field_41236).method_10221(biome).toString();
        biomeSamples.put(new class_2338(pos.method_10263() & ~15, 64, pos.method_10260() & ~15), name);
    }

    private static void checkAndStartCracking() {
        if (crackThread != null && crackThread.isAlive()) return;
        for (var entry : foundStructures.entrySet())
            if (entry.getValue().size() >= 2) { startCracking(entry.getKey(), entry.getValue()); return; }
    }

    private static void startCracking(StructureData.StructureType type, List<class_1923> positions) {
        cancelCrack = false; status.set(Status.CRACKING);
        crackThread = new Thread(() -> { try { crack(type, positions); } catch (Exception e) { if (!cancelCrack) status.set(Status.COLLECTING); } }, "SeedCracker");
        crackThread.setDaemon(true); crackThread.start();
    }

    private static void crack(StructureData.StructureType type, List<class_1923> positions) {
        class_1923 first = positions.get(0);
        int[] fr = StructureData.getRegion(type, first.field_9181, first.field_9180);
        int range = type.getRange();
        int offX = first.field_9181 - fr[0] * type.spacing, offZ = first.field_9180 - fr[1] * type.spacing;
        if (offX < 0 || offX >= range || offZ < 0 || offZ >= range) { status.set(Status.COLLECTING); return; }

        long regionConst = (long) fr[0] * 341873128712L + (long) fr[1] * 132897987541L + type.salt;
        long total = 1L << 48;
        long MASK = StructureData.LCG_MASK, MULT = StructureData.LCG_MULTIPLIER, ADD = StructureData.LCG_ADDEND;

        for (long s = 0; s < total; s++) {
            if (cancelCrack) return;
            if ((s & 0xFFFFF) == 0) crackProgress.set((s * 100) / total);
            long rs = (regionConst + s) & MASK;
            long internal = (rs ^ MULT) & MASK;
            long s1 = (internal * MULT + ADD) & MASK;
            int b1 = (int)(s1 >>> 17), r1 = (range & (range-1)) == 0 ? (int)((range*(long)b1)>>31) : b1 % range;
            if ((range & (range-1)) != 0 && b1-r1+(range-1) < 0) continue;
            if (r1 != offX) continue;
            long s2 = (s1 * MULT + ADD) & MASK;
            int b2 = (int)(s2 >>> 17), r2 = (range & (range-1)) == 0 ? (int)((range*(long)b2)>>31) : b2 % range;
            if ((range & (range-1)) != 0 && b2-r2+(range-1) < 0) continue;
            if (r2 != offZ) continue;

            boolean ok = true;
            for (int i = 1; i < positions.size() && ok; i++) ok = StructureData.testSeedForStructure(s, type, positions.get(i).field_9181, positions.get(i).field_9180);
            if (ok) for (var e : foundStructures.entrySet()) { if (e.getKey() == type) continue;
                for (class_1923 p : e.getValue()) if (!StructureData.testSeedForStructure(s, e.getKey(), p.field_9181, p.field_9180)) { ok = false; break; }
                if (!ok) break;
            }
            if (ok) {
                long found = s;
                crackedSeed.set(found); status.set(Status.FOUND); crackProgress.set(100);
                class_310 mc = class_310.method_1551();
                if (mc.field_1724 != null) mc.execute(() -> mc.field_1724.method_7353(
                        class_2561.method_43470("\u00A76[SeedCracker] \u00A7a\u00A7lSEED FOUND: \u00A7b" + found), false));
                return;
            }
        }
        status.set(Status.COLLECTING); crackProgress.set(0);
    }

    public static void copySeedToClipboard() {
        if (status.get() != Status.FOUND) return;
        class_310 mc = class_310.method_1551();
        mc.field_1774.method_1455(String.valueOf(crackedSeed.get()));
        if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470("\u00A76[SeedCracker] \u00A7aSeed copied!"), true);
    }
}
