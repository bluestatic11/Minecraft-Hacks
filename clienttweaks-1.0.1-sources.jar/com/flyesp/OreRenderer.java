package com.flyesp;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Ore Finder — scans for real ores using anti-anti-xray heuristics.
 * Shows ore locations as client-side chat messages (only you can see).
 * Also shows ore counts on HUD.
 */
public class OreRenderer {
    private static final List<AntiAntiXray.OreResult> cachedOres = new CopyOnWriteArrayList<>();
    private static int scanCooldown = 0;
    private static int lastOreCount = 0;
    private static final Set<class_2338> alertedOres = new HashSet<>();
    private static int chatCooldown = 0;

    public static int getLastOreCount() { return lastOreCount; }
    public static List<AntiAntiXray.OreResult> getCachedOres() { return cachedOres; }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!FlyEspModClient.oreFinderEnabled || client.field_1724 == null || client.field_1687 == null) {
                cachedOres.clear(); lastOreCount = 0; alertedOres.clear(); return;
            }

            if (--scanCooldown > 0) return;
            scanCooldown = 60;

            class_2338 center = client.field_1724.method_24515();
            List<AntiAntiXray.OreResult> results = AntiAntiXray.scanNearbyOres(client.field_1687, center, 2, 0.6f);
            cachedOres.clear(); cachedOres.addAll(results); lastOreCount = results.size();

            // Alert new high-confidence ores in chat (client-side only)
            if (--chatCooldown > 0) return;
            chatCooldown = 3; // Only alert every 3 scans to avoid spam

            Map<String, List<class_2338>> newOres = new LinkedHashMap<>();

            for (AntiAntiXray.OreResult ore : results) {
                if (ore.confidence < 0.5f) continue; // Only alert medium+ confidence
                if (alertedOres.contains(ore.pos)) continue;
                alertedOres.add(ore.pos);

                String name = getOreName(ore.block);
                String color = getOreColor(ore.block);
                String key = color + name;
                newOres.computeIfAbsent(key, k -> new ArrayList<>()).add(ore.pos);
            }

            // Send grouped alerts
            for (Map.Entry<String, List<class_2338>> entry : newOres.entrySet()) {
                List<class_2338> positions = entry.getValue();
                if (positions.size() == 1) {
                    class_2338 p = positions.get(0);
                    client.field_1724.method_7353(class_2561.method_43470(
                            "\u00A76[OreFinder] " + entry.getKey() + " \u00A77at [" +
                                    p.method_10263() + ", " + p.method_10264() + ", " + p.method_10260() + "]"), false);
                } else {
                    // Group nearby ores of same type
                    class_2338 first = positions.get(0);
                    client.field_1724.method_7353(class_2561.method_43470(
                            "\u00A76[OreFinder] " + entry.getKey() + " \u00A7fx" + positions.size() +
                                    " \u00A77near [" + first.method_10263() + ", " + first.method_10264() + ", " + first.method_10260() + "]"), false);
                }
            }

            // Clean up old alerted positions that are far away
            class_2338 playerPos = client.field_1724.method_24515();
            alertedOres.removeIf(pos -> pos.method_10262(playerPos) > 64 * 64);
        });
    }

    private static String getOreName(class_2248 block) {
        if (block == class_2246.field_10442 || block == class_2246.field_29029) return "Diamond";
        if (block == class_2246.field_10013 || block == class_2246.field_29220) return "Emerald";
        if (block == class_2246.field_10571 || block == class_2246.field_29026) return "Gold";
        if (block == class_2246.field_10212 || block == class_2246.field_29027) return "Iron";
        if (block == class_2246.field_10090 || block == class_2246.field_29028) return "Lapis";
        if (block == class_2246.field_10080 || block == class_2246.field_29030) return "Redstone";
        if (block == class_2246.field_27120 || block == class_2246.field_29221) return "Copper";
        if (block == class_2246.field_10418 || block == class_2246.field_29219) return "Coal";
        if (block == class_2246.field_22109) return "Ancient Debris";
        if (block == class_2246.field_23077) return "Nether Gold";
        if (block == class_2246.field_10213) return "Nether Quartz";
        return "Ore";
    }

    private static String getOreColor(class_2248 block) {
        if (block == class_2246.field_10442 || block == class_2246.field_29029) return "\u00A7b";
        if (block == class_2246.field_10013 || block == class_2246.field_29220) return "\u00A7a";
        if (block == class_2246.field_10571 || block == class_2246.field_29026) return "\u00A76";
        if (block == class_2246.field_10212 || block == class_2246.field_29027) return "\u00A7f";
        if (block == class_2246.field_10090 || block == class_2246.field_29028) return "\u00A79";
        if (block == class_2246.field_10080 || block == class_2246.field_29030) return "\u00A7c";
        if (block == class_2246.field_22109) return "\u00A74";
        return "\u00A77";
    }
}
