package com.flyesp;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class BaseFinder {
    private static final List<FoundBlock> foundBlocks = new CopyOnWriteArrayList<>();
    private static int scanCooldown = 0;
    private static int lastCount = 0;
    public static int getLastCount() { return lastCount; }

    private static final Set<class_2248> BASE_BLOCKS = new HashSet<>();
    static {
        BASE_BLOCKS.add(class_2246.field_10034); BASE_BLOCKS.add(class_2246.field_10380);
        BASE_BLOCKS.add(class_2246.field_10443); BASE_BLOCKS.add(class_2246.field_16328);
        BASE_BLOCKS.add(class_2246.field_10603);
        BASE_BLOCKS.add(class_2246.field_10199); BASE_BLOCKS.add(class_2246.field_10407);
        BASE_BLOCKS.add(class_2246.field_10063); BASE_BLOCKS.add(class_2246.field_10203);
        BASE_BLOCKS.add(class_2246.field_10600); BASE_BLOCKS.add(class_2246.field_10275);
        BASE_BLOCKS.add(class_2246.field_10051); BASE_BLOCKS.add(class_2246.field_10140);
        BASE_BLOCKS.add(class_2246.field_10320); BASE_BLOCKS.add(class_2246.field_10532);
        BASE_BLOCKS.add(class_2246.field_10268); BASE_BLOCKS.add(class_2246.field_10605);
        BASE_BLOCKS.add(class_2246.field_10373); BASE_BLOCKS.add(class_2246.field_10055);
        BASE_BLOCKS.add(class_2246.field_10068); BASE_BLOCKS.add(class_2246.field_10371);
        BASE_BLOCKS.add(class_2246.field_10485);
        BASE_BLOCKS.add(class_2246.field_10535); BASE_BLOCKS.add(class_2246.field_10105); BASE_BLOCKS.add(class_2246.field_10414);
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!FlyEspModClient.baseFinderEnabled || client.field_1724 == null || client.field_1687 == null) {
                foundBlocks.clear(); lastCount = 0; return;
            }
            if (--scanCooldown > 0) return;
            scanCooldown = 40;
            List<FoundBlock> found = new ArrayList<>();
            class_2338 pp = client.field_1724.method_24515();
            int chunkRange = 4;
            int pcx = pp.method_10263() >> 4, pcz = pp.method_10260() >> 4;
            for (int cx = pcx - chunkRange; cx <= pcx + chunkRange; cx++)
                for (int cz = pcz - chunkRange; cz <= pcz + chunkRange; cz++) {
                    if (!client.field_1687.method_8393(cx, cz)) continue;
                    class_2818 chunk = client.field_1687.method_8497(cx, cz);
                    class_2826[] sections = chunk.method_12006();
                    for (int si = 0; si < sections.length; si++) {
                        class_2826 section = sections[si];
                        if (section == null || section.method_38292()) continue;
                        int baseY = client.field_1687.method_31607() + (si * 16);
                        for (int x = 0; x < 16; x++)
                            for (int y = 0; y < 16; y++)
                                for (int z = 0; z < 16; z++) {
                                    class_2248 block = section.method_12254(x, y, z).method_26204();
                                    if (BASE_BLOCKS.contains(block))
                                        found.add(new FoundBlock(new class_2338(cx*16+x, baseY+y, cz*16+z), block));
                                }
                    }
                }
            foundBlocks.clear(); foundBlocks.addAll(found); lastCount = found.size();
        });
    }

    private static class FoundBlock {
        final class_2338 pos; final class_2248 block;
        FoundBlock(class_2338 pos, class_2248 block) { this.pos = pos; this.block = block; }
    }
}
