package com.flyesp;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Frame-interpolated Aim Assist — runs rotation every FRAME, not every tick.
 *
 * The tick event updates the target and calculates desired velocity.
 * The HUD render event (which fires every frame) applies a tiny fraction
 * of the rotation, making it perfectly smooth at any FPS.
 */
public class AimAssist {
    private static final double MAX_REACH = 5.0;
    private static final double FOV_ANGLE = 65.0;

    // Target data (updated per tick)
    private static float targetDeltaYaw = 0;
    private static float targetDeltaPitch = 0;
    private static boolean hasTarget = false;
    private static float aimHeight = 0.7f;

    // Smooth velocity (updated per frame)
    private static float velYaw = 0;
    private static float velPitch = 0;

    public static void registerFrameHandler() {
        // This runs EVERY FRAME — not every tick
        HudRenderCallback.EVENT.register((class_332 gfx, class_9779 dt) -> {
            if (!FlyEspModClient.aimAssistEnabled) return;
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null) return;

            class_746 player = mc.field_1724;
            float partialTick = dt.method_60637(true);

            if (!hasTarget) {
                // Smooth decay
                velYaw *= 0.95f;
                velPitch *= 0.95f;
                if (Math.abs(velYaw) > 0.001f || Math.abs(velPitch) > 0.001f) {
                    player.method_36456(player.method_36454() + velYaw * partialTick);
                    player.method_36457(clamp(player.method_36455() + velPitch * partialTick, -90f, 90f));
                }
                return;
            }

            // Recalculate angles every frame for smooth tracking
            class_1297 target = findBestTarget(mc, player);
            if (target == null) { hasTarget = false; return; }

            class_243 eyes = player.method_5836(partialTick);
            class_243 aimPoint = target.method_30950(partialTick).method_1031(0, target.method_17682() * aimHeight, 0);
            class_243 diff = aimPoint.method_1020(eyes);
            double dist = diff.method_1033();
            if (dist < 0.1) return;

            float wantYaw = (float) Math.toDegrees(Math.atan2(-diff.field_1352, diff.field_1350));
            float wantPitch = (float) Math.toDegrees(-Math.atan2(diff.field_1351, Math.sqrt(diff.field_1352 * diff.field_1352 + diff.field_1350 * diff.field_1350)));

            float yawDiff = wrapDegrees(wantYaw - player.method_36454());
            float pitchDiff = wantPitch - player.method_36455();

            float totalAngle = (float) Math.sqrt(yawDiff * yawDiff + pitchDiff * pitchDiff);
            if (totalAngle > FOV_ANGLE) return;

            // Speed curve
            float speed = (float) Math.pow(Math.min(totalAngle / (float) FOV_ANGLE, 1.0f), 0.3) * 22.0f + 3.0f;
            float distFactor = (float) (1.0 + (MAX_REACH - dist) * 0.2);
            speed *= distFactor;

            // Target velocity
            float rawYaw = yawDiff * speed * 0.012f;
            float rawPitch = pitchDiff * speed * 0.009f;

            // Single smooth lerp — but it runs every FRAME so it's naturally smooth
            velYaw += (rawYaw - velYaw) * 0.08f;
            velPitch += (rawPitch - velPitch) * 0.08f;

            velYaw = clamp(velYaw, -0.4f, 0.4f);
            velPitch = clamp(velPitch, -0.25f, 0.25f);

            // Apply per frame
            player.method_36456(player.method_36454() + velYaw);
            player.method_36457(clamp(player.method_36455() + velPitch, -90f, 90f));
        });
    }

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null) {
            hasTarget = false;
            return;
        }

        // Slowly drift aim height
        if (ThreadLocalRandom.current().nextInt(80) == 0) {
            aimHeight = 0.55f + ThreadLocalRandom.current().nextFloat() * 0.30f;
        }

        class_1297 target = findBestTarget(mc, mc.field_1724);
        hasTarget = (target != null);
    }

    private static class_1297 findBestTarget(class_310 mc, class_746 player) {
        class_1297 best = null;
        double bestDist = MAX_REACH;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity == player) continue;
            if (!(entity instanceof class_1309)) continue;
            if (!entity.method_5805()) continue;
            if (!(entity instanceof class_1657)) continue;

            double dist = player.method_5739(entity);
            if (dist > MAX_REACH || dist >= bestDist) continue;

            class_243 eyes = player.method_5836(1.0f);
            class_243 toEntity = entity.method_5836(1.0f).method_1020(eyes).method_1029();
            class_243 look = player.method_5720();
            double dot = look.method_1026(toEntity);
            double angle = Math.toDegrees(Math.acos(clamp((float) dot, -1f, 1f)));

            if (angle <= FOV_ANGLE) {
                best = entity;
                bestDist = dist;
            }
        }
        return best;
    }

    private static float wrapDegrees(float deg) {
        deg = deg % 360;
        if (deg >= 180) deg -= 360;
        if (deg < -180) deg += 360;
        return deg;
    }

    private static float clamp(float val, float min, float max) {
        return Math.max(min, Math.min(max, val));
    }
}
