package com.flyesp;

import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_9304;

/**
 * Auto XP — throws XP bottles to repair mending armor.
 *
 * Triggers when:
 * 1. Any equipped armor with Mending is below 40% durability
 * 2. No player within 10 blocks
 * 3. XP bottles in inventory
 */
public class AutoXP {
    private static int cooldown = 0;
    private static int previousSlot = -1;
    private static boolean isThrowing = false;
    private static int throwCount = 0;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1755 != null) return;
        if (cooldown > 0) { cooldown--; return; }

        class_746 player = mc.field_1724;

        if (isThrowing) { tickThrowing(mc, player); return; }

        cooldown = 20;

        if (isPlayerNearby(mc, player, 10.0)) return;
        if (!needsRepair(player)) return;

        int bottleSlot = findXPBottles(player.method_31548());
        if (bottleSlot == -1) return;

        previousSlot = player.method_31548().method_67532();
        isThrowing = true;
        throwCount = 0;

        if (bottleSlot >= 36 && bottleSlot <= 44) {
            // Hotbar slot
            player.method_31548().method_61496(bottleSlot - 36);
        } else {
            // Swap from main inventory to hotbar
            mc.field_1761.method_2906(
                    player.field_7512.field_7763, bottleSlot, 0, class_1713.field_7790, player);
            mc.field_1761.method_2906(
                    player.field_7512.field_7763, 36 + player.method_31548().method_67532(), 0, class_1713.field_7790, player);
            mc.field_1761.method_2906(
                    player.field_7512.field_7763, bottleSlot, 0, class_1713.field_7790, player);
        }
        cooldown = 3;
    }

    private static void tickThrowing(class_310 mc, class_746 player) {
        if (isPlayerNearby(mc, player, 10.0) || !needsRepair(player) || throwCount >= 5) {
            stopThrowing(mc, player); return;
        }

        class_1799 held = player.method_6047();
        if (!held.method_31574(class_1802.field_8287)) {
            int slot = findXPBottles(player.method_31548());
            if (slot == -1) { stopThrowing(mc, player); return; }
            if (slot >= 36 && slot <= 44) {
                player.method_31548().method_61496(slot - 36);
            } else {
                mc.field_1761.method_2906(
                        player.field_7512.field_7763, slot, 0, class_1713.field_7790, player);
                mc.field_1761.method_2906(
                        player.field_7512.field_7763, 36 + player.method_31548().method_67532(), 0, class_1713.field_7790, player);
                mc.field_1761.method_2906(
                        player.field_7512.field_7763, slot, 0, class_1713.field_7790, player);
            }
            cooldown = 3; return;
        }

        mc.field_1761.method_2919(player, class_1268.field_5808);
        player.method_6104(class_1268.field_5808);
        throwCount++;
        cooldown = 4;
    }

    private static void stopThrowing(class_310 mc, class_746 player) {
        isThrowing = false; throwCount = 0;
        if (previousSlot >= 0 && previousSlot < 9) player.method_31548().method_61496(previousSlot);
        previousSlot = -1;
        cooldown = 40;
    }

    private static boolean needsRepair(class_746 player) {
        class_1304[] armorSlots = { class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166 };
        for (class_1304 slot : armorSlots) {
            class_1799 armor = player.method_6118(slot);
            if (armor.method_7960() || !armor.method_7963()) continue;
            if (!hasMending(armor)) continue;
            float durability = 1.0f - ((float) armor.method_7919() / armor.method_7936());
            if (durability < 0.4f) return true;
        }
        return false;
    }

    private static boolean hasMending(class_1799 stack) {
        class_9304 enchantments = class_1890.method_57532(stack);
        for (var entry : enchantments.method_57539()) {
            if (entry.getKey().method_55840().contains("mending")) return true;
        }
        return false;
    }

    private static boolean isPlayerNearby(class_310 mc, class_746 self, double range) {
        for (var entity : mc.field_1687.method_18112()) {
            if (entity == self) continue;
            if (!(entity instanceof class_1657)) continue;
            if (self.method_5739(entity) < range) return true;
        }
        return false;
    }

    private static int findXPBottles(class_1661 inv) {
        for (int i = 0; i < 9; i++)
            if (inv.method_5438(i).method_31574(class_1802.field_8287)) return 36 + i;
        for (int i = 9; i < 36; i++)
            if (inv.method_5438(i).method_31574(class_1802.field_8287)) return i;
        return -1;
    }
}
