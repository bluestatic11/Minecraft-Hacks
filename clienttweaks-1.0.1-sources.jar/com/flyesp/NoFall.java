package com.flyesp;

import net.minecraft.class_310;

/**
 * No Fall — resets fall distance every tick to prevent fall damage.
 * Pure client-side, doesn't send any extra packets.
 */
public class NoFall {
    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        mc.field_1724.field_6017 = 0;
    }
}
