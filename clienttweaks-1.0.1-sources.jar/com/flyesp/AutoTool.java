package com.flyesp;

import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;

/**
 * Auto Tool — automatically switches to the best tool for the block you're mining.
 *
 * - Picks the tool with the fastest mining speed for the target block
 * - Only switches when you're actively looking at a block
 * - Prefers higher-tier tools (netherite > diamond > iron etc.)
 * - Swaps back when you stop mining
 */
public class AutoTool {
    private static int previousSlot = -1;
    private static boolean swapped = false;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1755 != null) return;

        class_746 player = mc.field_1724;

        // Only swap when looking at a block and holding attack
        if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1332
                || !mc.field_1690.field_1886.method_1434()) {
            return;
        }

        class_3965 blockHit = (class_3965) mc.field_1765;
        class_2338 pos = blockHit.method_17777();
        class_2680 state = mc.field_1687.method_8320(pos);

        if (state.method_26215()) return;

        // Find best tool in hotbar
        class_1661 inv = player.method_31548();
        int bestSlot = -1;
        float bestSpeed = 1.0f; // Default hand speed

        for (int i = 0; i < 9; i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) continue;

            float speed = stack.method_7924(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = i;
            }
        }

        // If we found a better tool and it's not already selected
        if (bestSlot >= 0 && bestSlot != inv.method_67532()) {
            inv.method_61496(bestSlot);
        }
    }
}
