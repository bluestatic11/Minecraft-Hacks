package com.flyesp;

/**
 * Panic Button — instantly disables ALL visible cheats with one key press.
 * Hit this before screen sharing or when someone is watching.
 *
 * Disables: ESP, X-Ray, Flight, HUD, all combat mods, everything visible.
 * Press again to re-enable everything that was on.
 */
public class PanicButton {
    private static boolean panicked = false;

    // Saved states
    private static boolean savedFly, savedEsp, savedXray, savedOreFinder, savedBaseFinder;
    private static boolean savedTriggerBot, savedAutoClicker, savedAimAssist, savedAntiKB;
    private static boolean savedVelocity, savedReach, savedAutoTotem, savedAutoGap;
    private static boolean savedAutoSprint, savedNoFall, savedFakeLag, savedAutoMine;
    private static boolean savedAutoTool, savedAutoXP, savedRadar, savedSeedCracker;
    private static boolean savedSafeAnchor, savedAutoCrystal, savedHud;

    public static boolean isPanicked() { return panicked; }

    public static void toggle() {
        if (!panicked) {
            // Save all states and disable everything
            savedFly = FlyEspModClient.flyEnabled;
            savedEsp = FlyEspModClient.espEnabled;
            savedXray = FlyEspModClient.xrayEnabled;
            savedOreFinder = FlyEspModClient.oreFinderEnabled;
            savedBaseFinder = FlyEspModClient.baseFinderEnabled;
            savedTriggerBot = FlyEspModClient.triggerBotEnabled;
            savedAutoClicker = FlyEspModClient.autoClickerEnabled;
            savedAimAssist = FlyEspModClient.aimAssistEnabled;
            savedAntiKB = FlyEspModClient.antiKBEnabled;
            savedVelocity = FlyEspModClient.velocityEnabled;
            savedReach = FlyEspModClient.reachEnabled;
            savedAutoTotem = FlyEspModClient.autoTotemEnabled;
            savedAutoGap = FlyEspModClient.autoGapEnabled;
            savedAutoSprint = FlyEspModClient.autoSprintEnabled;
            savedNoFall = FlyEspModClient.noFallEnabled;
            savedFakeLag = FlyEspModClient.fakeLagEnabled;
            savedAutoMine = FlyEspModClient.autoMineEnabled;
            savedAutoTool = FlyEspModClient.autoToolEnabled;
            savedAutoXP = FlyEspModClient.autoXPEnabled;
            savedRadar = FlyEspModClient.radarEnabled;
            savedSeedCracker = FlyEspModClient.seedCrackerEnabled;
            savedSafeAnchor = FlyEspModClient.safeAnchorEnabled;
            savedAutoCrystal = FlyEspModClient.autoCrystalEnabled;
            savedHud = FlyEspModClient.hudVisible;

            // Kill everything
            FlyEspModClient.flyEnabled = false;
            FlyEspModClient.espEnabled = false;
            FlyEspModClient.xrayEnabled = false;
            FlyEspModClient.oreFinderEnabled = false;
            FlyEspModClient.baseFinderEnabled = false;
            FlyEspModClient.triggerBotEnabled = false;
            FlyEspModClient.autoClickerEnabled = false;
            FlyEspModClient.aimAssistEnabled = false;
            FlyEspModClient.antiKBEnabled = false;
            FlyEspModClient.velocityEnabled = false;
            FlyEspModClient.reachEnabled = false;
            FlyEspModClient.autoTotemEnabled = false;
            FlyEspModClient.autoGapEnabled = false;
            FlyEspModClient.autoSprintEnabled = false;
            FlyEspModClient.noFallEnabled = false;
            FlyEspModClient.fakeLagEnabled = false;
            FlyEspModClient.autoMineEnabled = false;
            FlyEspModClient.autoToolEnabled = false;
            FlyEspModClient.autoXPEnabled = false;
            FlyEspModClient.radarEnabled = false;
            FlyEspModClient.seedCrackerEnabled = false;
            FlyEspModClient.safeAnchorEnabled = false;
            FlyEspModClient.autoCrystalEnabled = false;
            FlyEspModClient.hudVisible = false;

            StealthFly.disable();
            if (savedFakeLag) FakeLag.flush();

            panicked = true;
        } else {
            // Restore all saved states
            FlyEspModClient.flyEnabled = savedFly;
            FlyEspModClient.espEnabled = savedEsp;
            FlyEspModClient.xrayEnabled = savedXray;
            FlyEspModClient.oreFinderEnabled = savedOreFinder;
            FlyEspModClient.baseFinderEnabled = savedBaseFinder;
            FlyEspModClient.triggerBotEnabled = savedTriggerBot;
            FlyEspModClient.autoClickerEnabled = savedAutoClicker;
            FlyEspModClient.aimAssistEnabled = savedAimAssist;
            FlyEspModClient.antiKBEnabled = savedAntiKB;
            FlyEspModClient.velocityEnabled = savedVelocity;
            FlyEspModClient.reachEnabled = savedReach;
            FlyEspModClient.autoTotemEnabled = savedAutoTotem;
            FlyEspModClient.autoGapEnabled = savedAutoGap;
            FlyEspModClient.autoSprintEnabled = savedAutoSprint;
            FlyEspModClient.noFallEnabled = savedNoFall;
            FlyEspModClient.fakeLagEnabled = savedFakeLag;
            FlyEspModClient.autoMineEnabled = savedAutoMine;
            FlyEspModClient.autoToolEnabled = savedAutoTool;
            FlyEspModClient.autoXPEnabled = savedAutoXP;
            FlyEspModClient.radarEnabled = savedRadar;
            FlyEspModClient.seedCrackerEnabled = savedSeedCracker;
            FlyEspModClient.safeAnchorEnabled = savedSafeAnchor;
            FlyEspModClient.autoCrystalEnabled = savedAutoCrystal;
            FlyEspModClient.hudVisible = savedHud;

            panicked = false;
        }
    }
}
