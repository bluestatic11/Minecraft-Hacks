package com.flyesp;

import net.minecraft.class_10185;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class AutoTotem {
    private static int cooldown = 0;
    private static int freezeTicks = 0;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1755 != null) return;

        // Freeze movement during swap — stop all motion
        if (freezeTicks > 0) {
            mc.field_1724.field_3913.field_54155 = class_10185.field_54098;
            mc.field_1724.method_18799(class_243.field_1353);
            freezeTicks--;
            return;
        }

        if (cooldown > 0) { cooldown--; return; }

        class_746 player = mc.field_1724;
        class_1661 inv = player.method_31548();

        class_1799 offhand = inv.method_5438(class_1661.field_30639);
        if (offhand.method_31574(class_1802.field_8288)) return;

        int slot = findTotemSlot(inv);
        if (slot == -1) return;

        // Freeze movement for the swap duration
        freezeTicks = 4;

        int syncId = player.field_7512.field_7763;
        mc.field_1761.method_2906(syncId, slot, 0, class_1713.field_7790, player);
        mc.field_1761.method_2906(syncId, 45, 0, class_1713.field_7790, player);
        mc.field_1761.method_2906(syncId, slot, 0, class_1713.field_7790, player);
        cooldown = 3;
    }

    private static int findTotemSlot(class_1661 inv) {
        for (int i = 0; i < 9; i++)
            if (inv.method_5438(i).method_31574(class_1802.field_8288)) return 36 + i;
        for (int i = 9; i < 36; i++)
            if (inv.method_5438(i).method_31574(class_1802.field_8288)) return i;
        return -1;
    }
}
