package com.flyesp;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Reach Extender — adds 3.1-3.3 block reach (vanilla is 3.0).
 * Randomizes each tick so it's not a constant value.
 */
public class ReachExtender {
    public static double getReach() {
        return 3.0 + 0.1 + ThreadLocalRandom.current().nextDouble() * 0.2; // 3.1 - 3.3
    }
}
