package com.flyesp;

import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * Fake Game Mode Switcher — client-side only, enables cheat combos.
 *
 * Press F12 to cycle through modes that activate feature combos:
 *
 * Survival (default): Everything off
 * Fake Creative: Flight + No Fall + Auto Tool
 * Fake Spectator: Flight + No Fall + ESP (see through walls + fly around)
 */
public class GameModeSwitcher {
    private static int currentMode = 0;
    private static final String[] DISPLAY = {"\u00A7aSurvival", "\u00A7bFake Creative", "\u00A77Fake Spectator"};

    public static void cycle() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        currentMode = (currentMode + 1) % DISPLAY.length;

        // Disable everything first
        FlyEspModClient.flyEnabled = false;
        FlyEspModClient.noFallEnabled = false;
        FlyEspModClient.autoToolEnabled = false;
        FlyEspModClient.espEnabled = false;
        FlyEspModClient.xrayEnabled = false;
        StealthFly.disable();

        switch (currentMode) {
            case 1: // Fake Creative
                FlyEspModClient.flyEnabled = true;
                FlyEspModClient.noFallEnabled = true;
                FlyEspModClient.autoToolEnabled = true;
                break;
            case 2: // Fake Spectator
                FlyEspModClient.flyEnabled = true;
                FlyEspModClient.noFallEnabled = true;
                FlyEspModClient.espEnabled = true;
                FlyEspModClient.xrayEnabled = true;
                try { mc.field_1769.method_3279(); } catch (Exception ignored) {}
                break;
            case 0: // Survival — already disabled above
                try { mc.field_1769.method_3279(); } catch (Exception ignored) {}
                break;
        }

        mc.field_1724.method_7353(
                class_2561.method_43470("\u00A76[GameMode] \u00A7f" + DISPLAY[currentMode]), false);
    }

    public static String getCurrentDisplay() {
        return DISPLAY[currentMode];
    }
}
