package com.flyesp;

import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_640;
import net.minecraft.class_746;

/**
 * Vanish Detector — watches for signs of invisible/vanished staff nearby.
 *
 * Detects:
 * - Players who disappear from tab list while nearby (went vanish)
 * - Block changes with no visible player around
 * - Sounds from player actions with nobody visible
 * - Chunk loading in a direction where no player is visible
 */
public class VanishDetector {
    private static final Set<String> lastTabList = new HashSet<>();
    private static final Set<String> recentlyVanished = new HashSet<>();
    private static final Map<class_2338, class_2680> trackedBlocks = new HashMap<>();
    private static int scanCooldown = 0;
    private static int blockScanCooldown = 0;
    private static int alertCooldown = 0;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) return;

        class_746 player = mc.field_1724;

        // Check tab list every 2 seconds
        if (--scanCooldown <= 0) {
            scanCooldown = 40;
            checkTabList(mc, player);
        }

        // Check for block changes with nobody around every 1 second
        if (--blockScanCooldown <= 0) {
            blockScanCooldown = 20;
            checkBlockChanges(mc, player);
        }

        if (alertCooldown > 0) alertCooldown--;
    }

    /**
     * Detect players who suddenly disappear from tab list.
     */
    private static void checkTabList(class_310 mc, class_746 player) {
        Set<String> currentTab = new HashSet<>();
        Collection<class_640> players = mc.method_1562().method_45732();

        for (class_640 info : players) {
            String name = info.method_2966().name();
            if (name != null) currentTab.add(name);
        }

        // Check for players who were in tab but now aren't
        if (!lastTabList.isEmpty()) {
            for (String name : lastTabList) {
                if (!currentTab.contains(name) && !name.equals(player.method_5477().getString())) {
                    // Player left tab list — could be vanish or disconnect
                    // Check if they were nearby recently (within render distance)
                    boolean wasNearby = false;
                    for (var entity : mc.field_1687.method_18112()) {
                        if (entity instanceof net.minecraft.class_1657 p) {
                            if (p.method_5477().getString().equals(name) && player.method_5739(p) < 64) {
                                wasNearby = true;
                                break;
                            }
                        }
                    }

                    // If they were nearby and suddenly gone from tab = likely vanished
                    if (wasNearby) {
                        recentlyVanished.add(name);
                        alert(mc, "\u00A7c\u00A7l[VANISH] \u00A7e" + name + " \u00A7fmay have gone vanish nearby!");
                    }
                }
            }

            // Check for players who reappear (unvanish)
            for (String name : currentTab) {
                if (recentlyVanished.contains(name)) {
                    recentlyVanished.remove(name);
                    alert(mc, "\u00A7a[VANISH] \u00A7e" + name + " \u00A7freappeared (unvanished?)");
                }
            }
        }

        lastTabList.clear();
        lastTabList.addAll(currentTab);
    }

    /**
     * Detect blocks changing with no visible player nearby.
     */
    private static void checkBlockChanges(class_310 mc, class_746 player) {
        class_2338 pp = player.method_24515();
        int range = 16;

        // Track blocks around the player
        Map<class_2338, class_2680> currentBlocks = new HashMap<>();
        for (int x = -range; x <= range; x += 4)
            for (int y = -4; y <= 4; y += 2)
                for (int z = -range; z <= range; z += 4) {
                    class_2338 pos = pp.method_10069(x, y, z);
                    currentBlocks.put(pos, mc.field_1687.method_8320(pos));
                }

        // Compare with previous scan
        if (!trackedBlocks.isEmpty()) {
            int changes = 0;
            for (Map.Entry<class_2338, class_2680> entry : currentBlocks.entrySet()) {
                class_2680 old = trackedBlocks.get(entry.getKey());
                if (old != null && !old.equals(entry.getValue())) {
                    // Block changed — check if any visible player is nearby
                    boolean playerNearBlock = false;
                    for (var entity : mc.field_1687.method_18112()) {
                        if (entity == player) continue;
                        if (entity instanceof net.minecraft.class_1657) {
                            if (entity.method_24515().method_10262(entry.getKey()) < 100) { // 10 blocks
                                playerNearBlock = true;
                                break;
                            }
                        }
                    }

                    if (!playerNearBlock) {
                        changes++;
                    }
                }
            }

            if (changes >= 2 && alertCooldown <= 0) {
                alert(mc, "\u00A7c\u00A7l[VANISH] \u00A7f" + changes + " blocks changed with no visible player nearby!");
                alertCooldown = 200; // Don't spam — 10 second cooldown
            }
        }

        trackedBlocks.clear();
        trackedBlocks.putAll(currentBlocks);
    }

    private static void alert(class_310 mc, String message) {
        if (mc.field_1724 != null) {
            mc.field_1724.method_7353(class_2561.method_43470(message), false);
        }
    }

    public static void reset() {
        lastTabList.clear();
        recentlyVanished.clear();
        trackedBlocks.clear();
        scanCooldown = 0;
        blockScanCooldown = 0;
    }
}
