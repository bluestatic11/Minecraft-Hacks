package com.flyesp;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_746;
import net.minecraft.class_9362;

/**
 * Trigger Bot v4 — auto shield breaker.
 *
 * Detects when target is blocking with a shield, swaps to axe,
 * hits to disable shield, then swaps back to sword.
 *
 * Flow:
 * 1. Target not blocking → attack normally with current weapon
 * 2. Target blocking → find axe in hotbar → swap → hit (disables shield) → swap back
 */
public class TriggerBot {
    private static int delayTicks = 0;
    private static class_1297 lastTarget = null;
    private static final double MAX_REACH = 3.0;

    // Shield break state
    private static int previousSlot = -1;
    private static boolean swappedToAxe = false;
    private static int swapBackDelay = 0;
    private static int missTimer = 0;
    private static int nextMissAt = 300;
    private static boolean droppedShield = false;
    private static int reshieldDelay = 0;

    // Stun slam state: axe break shield → swap to mace → mace hit
    private static boolean stunSlamActive = false;
    private static int maceSlot = -1;
    private static int maceSwapDelay = 0;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1755 != null) return;

        class_746 player = mc.field_1724;

        // Handle mace slam follow-up after axe broke shield
        if (maceSwapDelay > 0) {
            maceSwapDelay--;
            if (maceSwapDelay == 0 && stunSlamActive && maceSlot >= 0) {
                // Swap to mace
                player.method_31548().method_61496(maceSlot);
                stunSlamActive = false;
                maceSlot = -1;
                delayTicks = ThreadLocalRandom.current().nextInt(1, 3); // Hit with mace after short delay
            }
            return;
        }

        // Handle swapping back to sword after shield break (or mace hit)
        if (swapBackDelay > 0) {
            swapBackDelay--;
            if (swapBackDelay == 0 && (swappedToAxe || player.method_6047().method_7909() instanceof class_9362) && previousSlot >= 0) {
                player.method_31548().method_61496(previousSlot);
                swappedToAxe = false;
                previousSlot = -1;
            }
            return;
        }

        if (delayTicks > 0) { delayTicks--; return; }

        if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1331) {
            lastTarget = null;
            return;
        }
        class_1297 target = ((class_3966) mc.field_1765).method_17782();
        if (!(target instanceof class_1309 living) || target == mc.field_1724) return;

        // Reach check
        double reach = FlyEspModClient.reachEnabled ? ReachExtender.getReach() : MAX_REACH;
        double distance = mc.field_1724.method_5739(target);
        if (distance > reach) return;

        lastTarget = target;

        // Don't attack while eating
        if (player.method_6115() && !player.method_6039()) return;

        // Re-shield after attacking
        if (reshieldDelay > 0) {
            reshieldDelay--;
            if (reshieldDelay == 0 && droppedShield) {
                // Hold right click again to re-raise shield
                mc.field_1690.field_1904.method_23481(true);
                droppedShield = false;
            }
            return;
        }

        // If we're blocking, drop shield briefly to attack
        if (player.method_6039()) {
            mc.field_1690.field_1904.method_23481(false); // Release right click = drop shield
            droppedShield = true;
            delayTicks = 1; // Wait 1 tick then attack
            return;
        }

        // Check if target is blocking with shield
        boolean targetBlocking = living.method_6039();

        // For shield break: don't wait for full cooldown, 50% is enough to disable shield
        // For normal attacks: wait for 85%
        float requiredCooldown = (targetBlocking || swappedToAxe) ? 0.01f : 0.85f;
        if (mc.field_1724.method_7261(0.5f) < requiredCooldown) return;

        if (targetBlocking && !swappedToAxe) {
            int axeSlot = findAxeSlot(player.method_31548());
            if (axeSlot >= 0) {
                class_1799 current = player.method_6047();
                if (!(current.method_7909() instanceof class_1743)) {
                    previousSlot = player.method_31548().method_67532();
                    player.method_31548().method_61496(axeSlot);
                    swappedToAxe = true;
                    delayTicks = 1; // 1 tick delay before hitting
                    return;
                }
            }
        }

        // Fake miss every 12-18 seconds
        missTimer++;
        if (missTimer >= nextMissAt) {
            missTimer = 0;
            nextMissAt = 240 + ThreadLocalRandom.current().nextInt(120); // 12-18 seconds (240-360 ticks)
            mc.field_1724.method_6104(class_1268.field_5808);
            delayTicks = ThreadLocalRandom.current().nextInt(2, 4);
            return;
        }

        // Normal attack
        mc.field_1761.method_2918(mc.field_1724, target);
        mc.field_1724.method_6104(class_1268.field_5808);

        if (swappedToAxe) {
            // Check for stun slam: 3+ blocks above target and mace in hotbar
            double heightAbove = player.method_23318() - target.method_23318();
            int foundMace = findMaceSlot(player.method_31548());

            if (heightAbove >= 3.0 && foundMace >= 0) {
                // Stun slam — axe broke shield, now swap to mace
                stunSlamActive = true;
                maceSlot = foundMace;
                maceSwapDelay = 1;
                swappedToAxe = false;
            } else {
                // Normal swap back to sword
                swapBackDelay = 1;
            }
        }

        // After mace hit, swap back to original weapon
        if (player.method_6047().method_7909() instanceof class_9362 && previousSlot >= 0) {
            swapBackDelay = 1;
        }

        // Re-raise shield after hitting if we dropped it
        if (droppedShield) {
            reshieldDelay = ThreadLocalRandom.current().nextInt(1, 3); // 1-2 ticks then re-shield
        }

        delayTicks = ThreadLocalRandom.current().nextInt(0, 2);
    }

    /**
     * Find an axe in hotbar (0-8). Prefers netherite > diamond > iron > stone > wood.
     */
    private static int findAxeSlot(class_1661 inv) {
        int bestSlot = -1;
        float bestDamage = 0;

        for (int i = 0; i < 9; i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7909() instanceof class_1743) {
                // Use tier ordering by checking destroy speed on a log
                float damage = stack.method_7909().method_7854().method_7924(
                        net.minecraft.class_2246.field_10431.method_9564());
                if (damage > bestDamage) {
                    bestDamage = damage;
                    bestSlot = i;
                }
            }
        }
        return bestSlot;
    }

    /**
     * Find a mace in hotbar (0-8).
     */
    private static int findMaceSlot(class_1661 inv) {
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_7909() instanceof class_9362) return i;
        }
        return -1;
    }
}
