package com.flyesp;

import java.util.*;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Radar Scanner — scans surroundings and alerts in chat (client-only messages).
 *
 * Detects:
 * - Villagers and wandering traders nearby
 * - Suspicious blocks that indicate player bases/activity:
 *   Placed blocks underground (torches, crafting tables, furnaces, beds,
 *   signs, doors, ladders, rails, etc.)
 * - Players entering detection range
 *
 * Alerts appear in chat but only you can see them (client-side messages).
 * Scans every 3 seconds to avoid lag.
 */
public class RadarScanner {
    private static int scanCooldown = 0;
    private static final Set<Long> alertedEntities = new HashSet<>();
    private static final Set<class_2338> alertedBlocks = new HashSet<>();
    private static int blockScanCooldown = 0;

    // Blocks that indicate player activity (not natural generation)
    private static final Set<class_2248> SUSPICIOUS_BLOCKS = new HashSet<>();

    static {
        SUSPICIOUS_BLOCKS.add(class_2246.field_10336);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10099);
        SUSPICIOUS_BLOCKS.add(class_2246.field_22092);
        SUSPICIOUS_BLOCKS.add(class_2246.field_22093);
        SUSPICIOUS_BLOCKS.add(class_2246.field_16541);
        SUSPICIOUS_BLOCKS.add(class_2246.field_22110);
        SUSPICIOUS_BLOCKS.add(class_2246.field_9980);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10181);
        SUSPICIOUS_BLOCKS.add(class_2246.field_16333);
        SUSPICIOUS_BLOCKS.add(class_2246.field_16334);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10333);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10485);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10535);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10105);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10414);
        SUSPICIOUS_BLOCKS.add(class_2246.field_9983);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10167);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10425);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10025);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10546);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10327);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10502);
        SUSPICIOUS_BLOCKS.add(class_2246.field_17350);
        SUSPICIOUS_BLOCKS.add(class_2246.field_23860);
        SUSPICIOUS_BLOCKS.add(class_2246.field_23152);
        SUSPICIOUS_BLOCKS.add(class_2246.field_23261);
        // Beds
        SUSPICIOUS_BLOCKS.add(class_2246.field_10120); SUSPICIOUS_BLOCKS.add(class_2246.field_10069);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10527); SUSPICIOUS_BLOCKS.add(class_2246.field_10561);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10461); SUSPICIOUS_BLOCKS.add(class_2246.field_10356);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10410); SUSPICIOUS_BLOCKS.add(class_2246.field_10610);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10109); SUSPICIOUS_BLOCKS.add(class_2246.field_10019);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10141); SUSPICIOUS_BLOCKS.add(class_2246.field_10288);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10621); SUSPICIOUS_BLOCKS.add(class_2246.field_10326);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10180); SUSPICIOUS_BLOCKS.add(class_2246.field_10230);
        // Signs
        SUSPICIOUS_BLOCKS.add(class_2246.field_10121); SUSPICIOUS_BLOCKS.add(class_2246.field_10187);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10411); SUSPICIOUS_BLOCKS.add(class_2246.field_10088);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10231); SUSPICIOUS_BLOCKS.add(class_2246.field_10391);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10330); SUSPICIOUS_BLOCKS.add(class_2246.field_10265);
        // Doors (player-placed underground = suspicious)
        SUSPICIOUS_BLOCKS.add(class_2246.field_9973);
        SUSPICIOUS_BLOCKS.add(class_2246.field_10453);
    }

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        class_746 player = mc.field_1724;

        // Entity scan every 60 ticks (3 seconds)
        if (--scanCooldown <= 0) {
            scanCooldown = 60;
            scanEntities(mc, player);
        }

        // Block scan every 400 ticks (20 seconds) — heavy at 256 block range
        if (--blockScanCooldown <= 0) {
            blockScanCooldown = 400;
            scanBlocks(mc, player);
        }
    }

    private static void scanEntities(class_310 mc, class_746 player) {
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity == player) continue;
            double dist = player.method_5739(entity);

            // Villager detection (64 block range) — check by entity type since class is server-only
            boolean isVillager = entity.method_5864() == class_1299.field_6077;
            if (isVillager && dist <= 128) {
                long id = entity.method_5628();
                if (!alertedEntities.contains(id)) {
                    alertedEntities.add(id);
                    String type = "Villager";
                    alert(mc, "\u00A7e\u00A7l[RADAR] \u00A7a" + type + " \u00A77detected "
                            + (int) dist + " blocks away ["
                            + entity.method_24515().method_10263() + ", "
                            + entity.method_24515().method_10264() + ", "
                            + entity.method_24515().method_10260() + "]");
                }
            }

            // Player detection (128 block range)
            if (entity instanceof class_1657 && dist <= 128) {
                long id = entity.method_5628();
                if (!alertedEntities.contains(id)) {
                    alertedEntities.add(id);
                    alert(mc, "\u00A7c\u00A7l[RADAR] \u00A7fPlayer \u00A7e" + entity.method_5477().getString()
                            + " \u00A77detected " + (int) dist + " blocks away");
                }
            }
        }

        // Clean up entities that left range
        alertedEntities.removeIf(id -> {
            for (class_1297 e : mc.field_1687.method_18112()) {
                if (e.method_5628() == id && player.method_5739(e) <= 128) return false;
            }
            return true;
        });
    }

    private static void scanBlocks(class_310 mc, class_746 player) {
        class_2338 pp = player.method_24515();
        int chunkRange = 16; // 256 blocks
        int pcx = pp.method_10263() >> 4, pcz = pp.method_10260() >> 4;

        Map<String, Integer> foundCounts = new LinkedHashMap<>();

        for (int cx = pcx - chunkRange; cx <= pcx + chunkRange; cx++)
            for (int cz = pcz - chunkRange; cz <= pcz + chunkRange; cz++) {
                if (!mc.field_1687.method_8393(cx, cz)) continue;
                class_2818 chunk = mc.field_1687.method_8497(cx, cz);
                class_2826[] sections = chunk.method_12006();

                for (int si = 0; si < sections.length; si++) {
                    class_2826 section = sections[si];
                    if (section == null || section.method_38292()) continue;
                    int baseY = mc.field_1687.method_31607() + (si * 16);

                    for (int x = 0; x < 16; x++)
                        for (int y = 0; y < 16; y++)
                            for (int z = 0; z < 16; z++) {
                                class_2680 state = section.method_12254(x, y, z);
                                class_2248 block = state.method_26204();
                                if (!SUSPICIOUS_BLOCKS.contains(block)) continue;

                                class_2338 pos = new class_2338(cx * 16 + x, baseY + y, cz * 16 + z);
                                if (alertedBlocks.contains(pos)) continue;
                                alertedBlocks.add(pos);

                                String name = block.method_63499()
                                        .replace("block.minecraft.", "")
                                        .replace("_", " ");
                                foundCounts.merge(name, 1, Integer::sum);
                            }
                }
            }

        // Alert summary
        if (!foundCounts.isEmpty()) {
            StringBuilder sb = new StringBuilder("\u00A76\u00A7l[RADAR] \u00A7eSuspicious blocks nearby: ");
            foundCounts.forEach((name, count) -> sb.append("\u00A7f").append(count).append("x ").append(name).append(" "));
            alert(mc, sb.toString().trim());
        }
    }

    private static void alert(class_310 mc, String message) {
        if (mc.field_1724 != null) {
            mc.field_1724.method_7353(class_2561.method_43470(message), false);
        }
    }

    public static void reset() {
        alertedEntities.clear();
        alertedBlocks.clear();
        scanCooldown = 0;
        blockScanCooldown = 0;
    }
}
