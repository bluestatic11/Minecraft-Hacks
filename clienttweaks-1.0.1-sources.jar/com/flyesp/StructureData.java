package com.flyesp;

import java.util.Random;

public class StructureData {
    public static final long LCG_MULTIPLIER = 0x5DEECE66DL;
    public static final long LCG_ADDEND = 0xBL;
    public static final long LCG_MASK = (1L << 48) - 1;

    public enum StructureType {
        VILLAGE(10,34,8,"Village"), DESERT_PYRAMID(10,32,8,"Desert Temple"),
        JUNGLE_PYRAMID(10,32,8,"Jungle Temple"), SWAMP_HUT(10,32,8,"Witch Hut"),
        IGLOO(10,32,8,"Igloo"), OCEAN_MONUMENT(10,32,5,"Monument"),
        WOODLAND_MANSION(10,80,20,"Mansion"), PILLAGER_OUTPOST(10,32,8,"Outpost"),
        OCEAN_RUIN(10,20,8,"Ocean Ruin"), SHIPWRECK(10,24,4,"Shipwreck"),
        RUINED_PORTAL(10,40,15,"Ruined Portal"), TRAIL_RUINS(10,34,8,"Trail Ruins"),
        TRIAL_CHAMBERS(10,34,12,"Trial Chambers"),
        BASTION_REMNANT(10,27,4,"Bastion"), NETHER_FORTRESS(10,27,4,"Fortress"),
        END_CITY(10,20,11,"End City");

        public final int salt, spacing, separation;
        public final String displayName;
        StructureType(int salt, int spacing, int separation, String displayName) {
            this.salt = salt; this.spacing = spacing; this.separation = separation; this.displayName = displayName;
        }
        public int getRange() { return spacing - separation; }
    }

    public static int[] getStructureChunk(long seed, StructureType type, int rx, int rz) {
        Random rand = new Random(getRegionSeed(seed, type, rx, rz));
        int range = type.getRange();
        return new int[]{ rx * type.spacing + (range > 0 ? rand.nextInt(range) : 0),
                          rz * type.spacing + (range > 0 ? rand.nextInt(range) : 0) };
    }

    public static long getRegionSeed(long seed, StructureType type, int rx, int rz) {
        return (long)rx * 341873128712L + (long)rz * 132897987541L + seed + type.salt;
    }

    public static int[] getRegion(StructureType type, int cx, int cz) {
        return new int[]{ Math.floorDiv(cx, type.spacing), Math.floorDiv(cz, type.spacing) };
    }

    public static boolean testSeedForStructure(long seed, StructureType type, int cx, int cz) {
        int[] r = getRegion(type, cx, cz);
        int[] expected = getStructureChunk(seed, type, r[0], r[1]);
        return expected[0] == cx && expected[1] == cz;
    }
}
