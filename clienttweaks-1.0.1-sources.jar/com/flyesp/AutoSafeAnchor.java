package com.flyesp;

import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;

/**
 * Auto Safe Anchor — when you use a respawn anchor to explode,
 * automatically places an obsidian block between you and the anchor
 * to absorb the blast damage.
 *
 * Flow:
 * 1. Detects when you're holding a glowstone and looking at a respawn anchor
 * 2. Before you charge/detonate, places obsidian between you and the anchor
 * 3. Protects you from the explosion while the target takes full damage
 *
 * You need obsidian in your hotbar for the shield block.
 */
public class AutoSafeAnchor {
    private static int cooldown = 0;
    private static boolean placedShield = false;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1687 == null || mc.field_1755 != null) return;

        if (cooldown > 0) { cooldown--; return; }

        class_746 player = mc.field_1724;

        // Check if looking at a respawn anchor
        if (mc.field_1765 == null || !(mc.field_1765 instanceof class_3965 blockHit)) return;
        class_2338 anchorPos = blockHit.method_17777();
        class_2680 anchorState = mc.field_1687.method_8320(anchorPos);

        if (!anchorState.method_27852(class_2246.field_23152)) return;

        // Check if we're holding glowstone (charging) or the anchor is charged (detonating)
        class_1799 mainHand = player.method_6047();
        class_1799 offHand = player.method_6079();
        boolean holdingGlowstone = mainHand.method_31574(class_1802.field_8801) || offHand.method_31574(class_1802.field_8801);

        // Get anchor charge level
        int charge = anchorState.method_11654(net.minecraft.class_4969.field_23153);

        // Only place shield if anchor is charged (about to explode) or we're charging it
        if (charge == 0 && !holdingGlowstone) return;

        // Find the block position between us and the anchor
        class_2338 shieldPos = getShieldPosition(player, anchorPos);
        if (shieldPos == null) return;

        // Check if shield position is air (can place)
        if (!mc.field_1687.method_8320(shieldPos).method_26215()) return;

        // Find obsidian in hotbar
        int obbySlot = findObsidianSlot(player);
        if (obbySlot == -1) return;

        // Swap to obsidian, place block, swap back
        int prevSlot = player.method_31548().method_67532();
        player.method_31548().method_61496(obbySlot);

        // Place the shield block
        class_2350 placeFace = getPlaceFace(player, shieldPos);
        class_2338 placeAgainst = shieldPos.method_10093(placeFace);

        if (!mc.field_1687.method_8320(placeAgainst).method_26215()) {
            class_3965 placeHit = new class_3965(
                    new class_243(shieldPos.method_10263() + 0.5, shieldPos.method_10264() + 0.5, shieldPos.method_10260() + 0.5),
                    placeFace.method_10153(),
                    placeAgainst,
                    false
            );
            mc.field_1761.method_2896(player, class_1268.field_5808, placeHit);
            placedShield = true;
        }

        // Swap back
        player.method_31548().method_61496(prevSlot);
        cooldown = 4;
    }

    /**
     * Place shield block directly in front of the player, between player and anchor.
     * One block ahead of the player's feet toward the anchor direction.
     */
    private static class_2338 getShieldPosition(class_746 player, class_2338 anchorPos) {
        class_2338 playerPos = player.method_24515();

        // Direction from player to anchor
        double dx = anchorPos.method_10263() - playerPos.method_10263();
        double dz = anchorPos.method_10260() - playerPos.method_10260();

        // Place one block in front of the player toward the anchor
        class_2338 shieldPos;
        if (Math.abs(dx) >= Math.abs(dz)) {
            int dir = dx > 0 ? 1 : -1;
            shieldPos = playerPos.method_10069(dir, 0, 0);
        } else {
            int dir = dz > 0 ? 1 : -1;
            shieldPos = playerPos.method_10069(0, 0, dir);
        }

        // If blocked, try one block up (protects upper body)
        if (!player.method_73183().method_8320(shieldPos).method_26215()) {
            shieldPos = shieldPos.method_10084();
        }

        return shieldPos;
    }

    /**
     * Get the best face to place against for a given position.
     */
    private static class_2350 getPlaceFace(class_746 player, class_2338 pos) {
        class_2338 playerPos = player.method_24515();
        double dx = playerPos.method_10263() - pos.method_10263();
        double dy = playerPos.method_10264() - pos.method_10264();
        double dz = playerPos.method_10260() - pos.method_10260();
        double ax = Math.abs(dx), ay = Math.abs(dy), az = Math.abs(dz);

        if (ay >= ax && ay >= az) return dy > 0 ? class_2350.field_11036 : class_2350.field_11033;
        if (ax >= az) return dx > 0 ? class_2350.field_11034 : class_2350.field_11039;
        return dz > 0 ? class_2350.field_11035 : class_2350.field_11043;
    }

    /**
     * Find obsidian in hotbar.
     */
    private static int findObsidianSlot(class_746 player) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_31574(class_1802.field_8281)) return i;
        }
        return -1;
    }
}
